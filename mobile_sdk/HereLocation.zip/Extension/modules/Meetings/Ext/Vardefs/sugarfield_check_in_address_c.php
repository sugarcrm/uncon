<?php
 // created: 2017-08-24 09:49:26
$dictionary['Meeting']['fields']['check_in_address_c']['labelValue']='Check-In Address';
$dictionary['Meeting']['fields']['check_in_address_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Meeting']['fields']['check_in_address_c']['enforced']='';
$dictionary['Meeting']['fields']['check_in_address_c']['dependency']='';

 ?>