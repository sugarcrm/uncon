<?php
 // created: 2017-08-23 16:25:33
$dictionary['Meeting']['fields']['check_in_latitude_c']['labelValue']='Check-in Latitude';
$dictionary['Meeting']['fields']['check_in_latitude_c']['enforced']='';
$dictionary['Meeting']['fields']['check_in_latitude_c']['dependency']='';

 ?>