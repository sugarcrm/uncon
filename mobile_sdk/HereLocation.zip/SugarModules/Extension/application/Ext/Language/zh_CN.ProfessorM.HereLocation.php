<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => '帐户',
  'Contacts' => '联系人',
  'Tasks' => '任务',
  'Opportunities' => '商业机会',
  'Products' => '已报价单项',
  'Quotes' => '报价',
  'Bugs' => '缺陷',
  'Cases' => '客户反馈',
  'Leads' => '潜在客户',
  'Project' => '项目',
  'ProjectTask' => '项目任务',
  'Prospects' => '目标',
  'KBContents' => '知识库',
  'RevenueLineItems' => '营收单项',
);