<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Sąskaita',
  'Contacts' => 'Kontaktas',
  'Tasks' => 'Užduotis',
  'Opportunities' => 'Galimybė',
  'Products' => 'Įvykdyto pasiūlymo eilutės prekė',
  'Quotes' => 'Pasiūlymas',
  'Bugs' => 'Triktys',
  'Cases' => 'Atvejis',
  'Leads' => 'Galimas klientas',
  'Project' => 'Projektas',
  'ProjectTask' => 'Projekto užduotis',
  'Prospects' => 'Adresatas',
  'KBContents' => 'Žinių bazė',
  'RevenueLineItems' => 'Pajamų eilutės prekės',
);