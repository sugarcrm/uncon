<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Kompanija',
  'Contacts' => 'Kontakt',
  'Tasks' => 'Zadatak',
  'Opportunities' => 'Prodajna prilika',
  'Products' => 'Proizvod',
  'Quotes' => 'Ponuda',
  'Bugs' => 'Defekti',
  'Cases' => 'Slučaj:',
  'Leads' => 'Potencijalni klijent',
  'Project' => 'Projekat',
  'ProjectTask' => 'Projektni Zadatak',
  'Prospects' => 'Cilj',
  'KBContents' => 'Baza Znanja',
  'RevenueLineItems' => 'Stavke prihoda',
);