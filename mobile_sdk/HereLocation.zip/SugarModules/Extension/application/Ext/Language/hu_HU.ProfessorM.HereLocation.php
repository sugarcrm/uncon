<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Kliens',
  'Contacts' => 'Kapcsolat',
  'Tasks' => 'Feladat',
  'Opportunities' => 'Lehetőség',
  'Products' => 'Megajánlott Tétel',
  'Quotes' => 'Árajánlat',
  'Bugs' => 'Hibák',
  'Cases' => 'Eset',
  'Leads' => 'Ajánlás',
  'Project' => 'Projekt',
  'ProjectTask' => 'Projektfeladat',
  'Prospects' => 'Cél',
  'KBContents' => 'Tudásbázis',
  'RevenueLineItems' => 'Bevételi sorok',
);