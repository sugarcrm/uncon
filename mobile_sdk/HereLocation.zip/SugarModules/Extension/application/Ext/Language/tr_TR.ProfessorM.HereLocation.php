<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Müşteri',
  'Contacts' => 'Kontak',
  'Tasks' => 'Görev',
  'Opportunities' => 'Fırsat',
  'Products' => 'Teklif Kalemi',
  'Quotes' => 'Teklif',
  'Bugs' => 'Hatalar',
  'Cases' => 'Talep',
  'Leads' => 'Potansiyel',
  'Project' => 'Proje',
  'ProjectTask' => 'Proje Görevi',
  'Prospects' => 'Hedef',
  'KBContents' => 'Bilgi Tabanı',
  'RevenueLineItems' => 'Gelir Kalemleri',
);