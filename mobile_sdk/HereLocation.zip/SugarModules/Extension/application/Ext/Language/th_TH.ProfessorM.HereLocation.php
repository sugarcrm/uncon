<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'บัญชี',
  'Contacts' => 'ที่อยู่ติดต่อ',
  'Tasks' => 'งาน',
  'Opportunities' => 'โอกาสทางการขาย',
  'Products' => 'รายการบรรทัดการเสนอราคา',
  'Quotes' => 'การเสนอราคา',
  'Bugs' => 'บัก',
  'Cases' => 'เคส',
  'Leads' => 'ผู้สนใจ',
  'Project' => 'โครงการ',
  'ProjectTask' => 'งานของโครงการ',
  'Prospects' => 'เป้าหมาย',
  'KBContents' => 'ฐานความรู้',
  'RevenueLineItems' => 'รายการบรรทัดรายได้',
);