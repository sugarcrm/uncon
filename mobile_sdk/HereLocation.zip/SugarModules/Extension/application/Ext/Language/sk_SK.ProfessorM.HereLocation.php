<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Účet',
  'Contacts' => 'Kontakt',
  'Tasks' => 'Úloha',
  'Opportunities' => 'Príležitosť',
  'Products' => 'Položka ponuky',
  'Quotes' => 'Ponuka',
  'Bugs' => 'Chyby',
  'Cases' => 'Prípad',
  'Leads' => 'Záujemca',
  'Project' => 'Projekt',
  'ProjectTask' => 'Projektová úloha',
  'Prospects' => 'Cieľ',
  'KBContents' => 'Báza znalostí',
  'RevenueLineItems' => 'Položky krivky výnosu',
);