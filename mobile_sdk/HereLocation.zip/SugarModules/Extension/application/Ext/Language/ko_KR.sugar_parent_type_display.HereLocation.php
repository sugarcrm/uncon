<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => '거래처',
  'Contacts' => '연락처',
  'Tasks' => '과제',
  'Opportunities' => '예비고객',
  'Products' => '견적 라인아이템',
  'Quotes' => '견적',
  'Bugs' => '버그',
  'Cases' => '사례',
  'Leads' => '관심고객:',
  'Project' => '프로젝트',
  'ProjectTask' => '프로젝트 과제',
  'Prospects' => '목표고객',
  'KBContents' => '지식 기반',
  'RevenueLineItems' => '매출 라인 품목',
);