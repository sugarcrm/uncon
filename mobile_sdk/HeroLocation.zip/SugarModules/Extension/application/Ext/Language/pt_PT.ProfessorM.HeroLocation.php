<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Conta',
  'Contacts' => 'Contacto',
  'Tasks' => 'Tarefa',
  'Opportunities' => 'Oportunidade',
  'Products' => 'Item de Linha Cotado',
  'Quotes' => 'Cotação',
  'Bugs' => 'Erros',
  'Cases' => 'Ocorrência',
  'Leads' => 'Cliente Potencial',
  'Project' => 'Projecto',
  'ProjectTask' => 'Tarefa de Projecto',
  'Prospects' => 'Alvo',
  'KBContents' => 'Base de Conhecimento',
  'RevenueLineItems' => 'Itens de Linha de Receita',
);