<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Uzņēmums',
  'Contacts' => 'Kontaktpersona',
  'Tasks' => 'Uzdevums',
  'Opportunities' => 'Iespēja',
  'Products' => 'Piedāvājuma rinda',
  'Quotes' => 'Piedāvājums',
  'Bugs' => 'Kļūdas',
  'Cases' => 'Pieteikums',
  'Leads' => 'Interesents',
  'Project' => 'Projekts',
  'ProjectTask' => 'Projekta uzdevums',
  'Prospects' => 'Mērķis',
  'KBContents' => 'Zināšanu bāze',
  'RevenueLineItems' => 'Ieņēmumu posteņi',
);