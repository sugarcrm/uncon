<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Cont:',
  'Contacts' => 'lista contact',
  'Tasks' => 'Sarcina',
  'Opportunities' => 'Oportunitate',
  'Products' => 'Element din ofertă',
  'Quotes' => 'Ofertă',
  'Bugs' => 'Probleme',
  'Cases' => 'Caz:',
  'Leads' => 'Client potențial',
  'Project' => 'Proiect',
  'ProjectTask' => 'Sarcina de proiect',
  'Prospects' => 'Tinta:',
  'KBContents' => 'Baza de cunostinte',
  'RevenueLineItems' => 'Linii de venit',
);