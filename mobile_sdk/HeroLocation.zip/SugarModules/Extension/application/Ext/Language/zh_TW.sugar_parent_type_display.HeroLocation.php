<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => '帳戶',
  'Contacts' => '連絡人',
  'Tasks' => '工作',
  'Opportunities' => '商機',
  'Products' => '報價項目',
  'Quotes' => '報價',
  'Bugs' => '錯誤',
  'Cases' => '實例',
  'Leads' => '潛在客戶',
  'Project' => '專案',
  'ProjectTask' => '專案工作',
  'Prospects' => '目標',
  'KBContents' => '知識庫',
  'RevenueLineItems' => '營收項目',
);