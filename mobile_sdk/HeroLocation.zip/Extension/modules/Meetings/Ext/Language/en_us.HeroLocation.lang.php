<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_CHECKIN_TIME'] = 'Check-in Time';
$mod_strings['LBL_CHECK_IN_LATITUDE'] = 'Check-in Latitude';
$mod_strings['LBL_CHECK_IN_LONGITUDE'] = 'Check-in Longitude';
$mod_strings['LBL_CHECK_IN_TIME'] = 'Check-In Time';
$mod_strings['LBL_CHECK_IN_ADDRESS'] = 'Check-In Address';
