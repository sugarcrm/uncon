<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_CONTACT_NAME'] = 'Student:';
$mod_strings['LBL_LIST_CONTACT'] = 'Student';
$mod_strings['LBL_CREATE_CONTACT'] = 'As Student';
$mod_strings['LBL_CREATE_LEAD'] = 'As Applicant';
$mod_strings['LBL_REVENUELINEITEMS'] = 'Funding Line Items';
