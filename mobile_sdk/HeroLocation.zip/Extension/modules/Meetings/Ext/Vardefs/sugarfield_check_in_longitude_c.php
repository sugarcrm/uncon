<?php
 // created: 2017-08-23 16:26:46
$dictionary['Meeting']['fields']['check_in_longitude_c']['labelValue']='Check-in Longitude';
$dictionary['Meeting']['fields']['check_in_longitude_c']['enforced']='';
$dictionary['Meeting']['fields']['check_in_longitude_c']['dependency']='';

 ?>