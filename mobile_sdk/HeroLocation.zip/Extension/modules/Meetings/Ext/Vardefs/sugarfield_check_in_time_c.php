<?php
 // created: 2017-08-23 16:56:50
$dictionary['Meeting']['fields']['check_in_time_c']['labelValue']='Check-In Time';
$dictionary['Meeting']['fields']['check_in_time_c']['enforced']='';
$dictionary['Meeting']['fields']['check_in_time_c']['dependency']='';

 ?>