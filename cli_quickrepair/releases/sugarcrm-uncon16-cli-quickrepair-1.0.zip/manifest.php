<?php
$manifest = array (
  'id' => 'uncon16-cli-quickrepair',
  'name' => 'UnCon 2016 CLI Quick Repair and Rebuild',
  'description' => 'UnCon 2016 CLI Quick Repair and Rebuild',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2016-06-12 08:46:52',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.7.[1-9].[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Console/RegisterQuickRepairCommand.php',
      'to' => 'custom/Extension/application/Ext/Console/RegisterQuickRepairCommand.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/src/Console/Command/QuickRepairCommand.php',
      'to' => 'custom/src/Console/Command/QuickRepairCommand.php',
    ),
  ),
);
