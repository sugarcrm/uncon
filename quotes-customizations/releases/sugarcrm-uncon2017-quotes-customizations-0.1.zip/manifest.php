<?php
$manifest = array (
  'id' => 'uncon2017-quotes-customizations',
  'name' => 'Quotes Customizations Uncon 2017',
  'description' => 'Installs the custom fields and files for the Quotes SugarCon 2017 Tutorial',
  'version' => '0.1',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2017-08-30 14:57:56',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.9.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/modules/Quotes/clients/base/fields/percent/percent.js',
      'to' => 'custom/modules/Quotes/clients/base/fields/percent/percent.js',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/modules/Quotes/clients/base/fields/percent/quote-data-grand-totals-header.hbs',
      'to' => 'custom/modules/Quotes/clients/base/fields/percent/quote-data-grand-totals-header.hbs',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/modules/Quotes/clients/base/views/quote-data-grand-totals-header/quote-data-grand-totals-header.php',
      'to' => 'custom/modules/Quotes/clients/base/views/quote-data-grand-totals-header/quote-data-grand-totals-header.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/post_execute.php',
      'to' => 'post_execute.php',
    ),
  ),
  'post_execute' => 
  array (
    0 => '<basepath>/src/post_execute.php',
  ),
  'custom_fields' => 
  array (
    0 => 
    array (
      'name' => 'total_damage_amount_c',
      'audited' => false,
      'calculated' => true,
      'comment' => 'Total Damage Amount calculated from Products discount_amount rollup',
      'default_value' => '0',
      'duplicate_merge' => false,
      'enforced' => true,
      'formula' => 'rollupConditionalSum($products, "total_amount", "type_name", "Property")',
      'help' => 'Total Damage Amount calculated from Products discount_amount rollup',
      'importable' => 'true',
      'label' => 'LBL_TOTAL_DAMAGE_AMOUNT',
      'len' => '26,2',
      'massupdate' => false,
      'module' => 'ProductBundles',
      'required' => false,
      'reportable' => true,
      'type' => 'currency',
    ),
    1 => 
    array (
      'name' => 'total_labor_amount_c',
      'audited' => false,
      'calculated' => true,
      'comment' => 'Total Labor Amount calculated from Products discount_amount rollup',
      'default_value' => '0',
      'duplicate_merge' => false,
      'enforced' => true,
      'formula' => 'rollupConditionalSum($products, "total_amount", "type_name", "Labor")',
      'help' => 'Total Labor Amount calculated from Products discount_amount rollup',
      'importable' => 'true',
      'label' => 'LBL_TOTAL_LABOR_AMOUNT',
      'len' => '26,2',
      'massupdate' => false,
      'module' => 'ProductBundles',
      'required' => false,
      'reportable' => true,
      'type' => 'currency',
    ),
    2 => 
    array (
      'name' => 'total_damage_amount_c',
      'audited' => false,
      'calculated' => true,
      'comment' => 'Total Damage Amount calculated from ProductBundles total_damage_amount_c rollup',
      'default_value' => '0',
      'duplicate_merge' => false,
      'enforced' => true,
      'formula' => 'rollupCurrencySum($product_bundles, "total_damage_amount_c")',
      'help' => 'Total Damage Amount calculated from ProductBundles total_damage_amount_c rollup',
      'importable' => 'true',
      'label' => 'LBL_TOTAL_DAMAGE_AMOUNT',
      'len' => '26,2',
      'massupdate' => false,
      'module' => 'Quotes',
      'required' => false,
      'reportable' => true,
      'type' => 'currency',
    ),
    3 => 
    array (
      'name' => 'total_damage_percent_c',
      'audited' => false,
      'calculated' => true,
      'comment' => 'Total Damage Percent calculated from ProductBundles total_damage_amount_c rollup',
      'default_value' => '0',
      'dbType' => 'decimal',
      'duplicate_merge' => false,
      'enforced' => true,
      'formula' => 'ifElse(not(equal($total_damage_amount_c, 0)), mul(divide($total_damage_amount_c, $total),100), 0)',
      'help' => 'Total Damage Percent calculated from ProductBundles total_damage_amount_c rollup',
      'importable' => 'true',
      'label' => 'LBL_TOTAL_DAMAGE_PERCENT',
      'len' => '26,2',
      'massupdate' => false,
      'module' => 'Quotes',
      'required' => false,
      'reportable' => true,
      'type' => 'float',
    ),
    4 => 
    array (
      'name' => 'total_labor_amount_c',
      'audited' => false,
      'calculated' => true,
      'comment' => 'Total Labor Amount calculated from Products discount_amount rollup',
      'default_value' => '0',
      'duplicate_merge' => false,
      'enforced' => true,
      'formula' => 'rollupCurrencySum($product_bundles, "total_labor_amount_c")',
      'help' => 'Total Labor Amount calculated from ProductBundles total_labor_amount_c rollup',
      'importable' => 'true',
      'label' => 'LBL_TOTAL_LABOR_AMOUNT',
      'len' => '26,2',
      'massupdate' => false,
      'module' => 'Quotes',
      'required' => false,
      'reportable' => true,
      'type' => 'currency',
    ),
    5 => 
    array (
      'name' => 'total_labor_percent_c',
      'audited' => false,
      'calculated' => true,
      'comment' => 'Total Labor Percent calculated from ProductBundles total_labor_amount_c rollup',
      'default_value' => '0',
      'duplicate_merge' => false,
      'enforced' => true,
      'formula' => 'ifElse(not(equal($total_labor_amount_c, 0)), mul(divide($total_labor_amount_c, $total),100), 0)',
      'help' => 'Total Labor Percent calculated from ProductBundles total_labor_amount_c rollup',
      'importable' => 'true',
      'label' => 'LBL_TOTAL_LABOR_PERCENT',
      'len' => '26,2',
      'massupdate' => false,
      'module' => 'Quotes',
      'required' => false,
      'reportable' => true,
      'type' => 'float',
    ),
  ),
);
