<?php
$manifest = array (
  'id' => 'uncon16-build-a-dashlet-0.0.1',
  'name' => 'SugarCRM UnCon 2016 Build a Dashlet Demo',
  'description' => 'SugarCRM UnCon 2016 Build a Dashlet Demo',
  'version' => '0.0.1',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2016-06-06 15:41:11',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.7.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/api/EngagementDashletDataApi.php',
      'to' => 'custom/clients/base/api/EngagementDashletDataApi.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/engagement/engagement.hbs',
      'to' => 'custom/clients/base/views/engagement/engagement.hbs',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/engagement/engagement.js',
      'to' => 'custom/clients/base/views/engagement/engagement.js',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/engagement/engagement.php',
      'to' => 'custom/clients/base/views/engagement/engagement.php',
    ),
  ),
);
