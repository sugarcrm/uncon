<?php
$manifest = array (
  'id' => 'uncon16-cli-helloworld',
  'name' => 'UnCon 2016 CLI Hello World',
  'description' => 'UnCon 2016 CLI Hello World',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2016-06-12 05:40:18',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.7.[1-9]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/test.php',
      'to' => 'custom/test.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Console/HelloWorldCommand.php',
      'to' => 'custom/Extension/application/Ext/Console/HelloWorldCommand.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/src/Console/Command/HelloWorldCommand.php',
      'to' => 'custom/src/Console/Command/HelloWorldCommand.php',
    ),
  ),
);
