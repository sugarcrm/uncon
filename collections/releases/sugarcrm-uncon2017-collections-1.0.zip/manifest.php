<?php
$manifest = array (
  'id' => 'uncon2017-collections',
  'name' => 'UnCon 2017 Collections Demo',
  'description' => 'UnCon 2017 Collections Demo',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2017-09-28 22:51:35',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7\\.(9|10).*',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/events/events.js',
      'to' => 'custom/clients/base/views/events/events.js',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/events/events.php',
      'to' => 'custom/clients/base/views/events/events.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/events/list-bottom.hbs',
      'to' => 'custom/clients/base/views/events/list-bottom.hbs',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/events/records.hbs',
      'to' => 'custom/clients/base/views/events/records.hbs',
    ),
    4 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/events/row.hbs',
      'to' => 'custom/clients/base/views/events/row.hbs',
    ),
    5 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Include/Equipment.php',
      'to' => 'custom/Extension/application/Ext/Include/Equipment.php',
    ),
    6 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Include/Powers.php',
      'to' => 'custom/Extension/application/Ext/Include/Powers.php',
    ),
    7 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Language/en_us.Equipment.php',
      'to' => 'custom/Extension/application/Ext/Language/en_us.Equipment.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Language/en_us.Powers.php',
      'to' => 'custom/Extension/application/Ext/Language/en_us.Powers.php',
    ),
    9 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/TableDictionary/leads_msgc_equipment_1.php',
      'to' => 'custom/Extension/application/Ext/TableDictionary/leads_msgc_equipment_1.php',
    ),
    10 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/TableDictionary/msgc_equipment_contacts.php',
      'to' => 'custom/Extension/application/Ext/TableDictionary/msgc_equipment_contacts.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/TableDictionary/msgc_powers_leads.php',
      'to' => 'custom/Extension/application/Ext/TableDictionary/msgc_powers_leads.php',
    ),
    12 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Contacts/Ext/clients/base/views/record/equipment.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/clients/base/views/record/equipment.php',
    ),
    13 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Contacts/Ext/Language/en_us.Equipment.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Language/en_us.Equipment.php',
    ),
    14 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Contacts/Ext/Vardefs/equipment.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Vardefs/equipment.php',
    ),
    15 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Contacts/Ext/Vardefs/msgc_equipment_contacts_Contacts.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Vardefs/msgc_equipment_contacts_Contacts.php',
    ),
    16 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/clients/base/layouts/extra-info/equip-powers.php',
      'to' => 'custom/Extension/modules/Leads/Ext/clients/base/layouts/extra-info/equip-powers.php',
    ),
    17 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/clients/base/views/record/equip_powers.php',
      'to' => 'custom/Extension/modules/Leads/Ext/clients/base/views/record/equip_powers.php',
    ),
    18 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/Language/en_us.customleads_msgc_equipment_1.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.customleads_msgc_equipment_1.php',
    ),
    19 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/Language/en_us.Powers.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.Powers.php',
    ),
    20 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/Vardefs/equip_powers.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/equip_powers.php',
    ),
    21 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/Vardefs/leads_msgc_equipment_1_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/leads_msgc_equipment_1_Leads.php',
    ),
    22 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/Vardefs/msgc_powers_leads_Leads.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/msgc_powers_leads_Leads.php',
    ),
    23 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/msgc_Equipment/Ext/clients/base/layouts/subpanels/leads_msgc_equipment_1_msgc_Equipment.php',
      'to' => 'custom/Extension/modules/msgc_Equipment/Ext/clients/base/layouts/subpanels/leads_msgc_equipment_1_msgc_Equipment.php',
    ),
    24 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/msgc_Equipment/Ext/clients/base/layouts/subpanels/msgc_equipment_contacts_msgc_Equipment.php',
      'to' => 'custom/Extension/modules/msgc_Equipment/Ext/clients/base/layouts/subpanels/msgc_equipment_contacts_msgc_Equipment.php',
    ),
    25 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/msgc_Equipment/Ext/Language/en_us.customleads_msgc_equipment_1.php',
      'to' => 'custom/Extension/modules/msgc_Equipment/Ext/Language/en_us.customleads_msgc_equipment_1.php',
    ),
    26 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/msgc_Equipment/Ext/Language/en_us.lang.php',
      'to' => 'custom/Extension/modules/msgc_Equipment/Ext/Language/en_us.lang.php',
    ),
    27 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/msgc_Equipment/Ext/Vardefs/leads_msgc_equipment_1_msgc_Equipment.php',
      'to' => 'custom/Extension/modules/msgc_Equipment/Ext/Vardefs/leads_msgc_equipment_1_msgc_Equipment.php',
    ),
    28 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/msgc_Equipment/Ext/Vardefs/msgc_equipment_contacts_msgc_Equipment.php',
      'to' => 'custom/Extension/modules/msgc_Equipment/Ext/Vardefs/msgc_equipment_contacts_msgc_Equipment.php',
    ),
    29 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/msgc_Powers/Ext/clients/base/layouts/subpanels/msgc_powers_leads_msgc_Powers.php',
      'to' => 'custom/Extension/modules/msgc_Powers/Ext/clients/base/layouts/subpanels/msgc_powers_leads_msgc_Powers.php',
    ),
    30 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/msgc_Powers/Ext/Language/en_us.Powers.php',
      'to' => 'custom/Extension/modules/msgc_Powers/Ext/Language/en_us.Powers.php',
    ),
    31 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/msgc_Powers/Ext/Vardefs/msgc_powers_leads_msgc_Powers.php',
      'to' => 'custom/Extension/modules/msgc_Powers/Ext/Vardefs/msgc_powers_leads_msgc_Powers.php',
    ),
    32 => 
    array (
      'from' => '<basepath>/src/custom/metadata/leads_msgc_equipment_1MetaData.php',
      'to' => 'custom/metadata/leads_msgc_equipment_1MetaData.php',
    ),
    33 => 
    array (
      'from' => '<basepath>/src/custom/metadata/msgc_equipment_contactsMetaData.php',
      'to' => 'custom/metadata/msgc_equipment_contactsMetaData.php',
    ),
    34 => 
    array (
      'from' => '<basepath>/src/custom/metadata/msgc_powers_leadsMetaData.php',
      'to' => 'custom/metadata/msgc_powers_leadsMetaData.php',
    ),
    35 => 
    array (
      'from' => '<basepath>/src/custom/modules/Contacts/clients/base/fields/equipment/detail.hbs',
      'to' => 'custom/modules/Contacts/clients/base/fields/equipment/detail.hbs',
    ),
    36 => 
    array (
      'from' => '<basepath>/src/custom/modules/Contacts/clients/base/fields/equipment/edit.hbs',
      'to' => 'custom/modules/Contacts/clients/base/fields/equipment/edit.hbs',
    ),
    37 => 
    array (
      'from' => '<basepath>/src/custom/modules/Contacts/clients/base/fields/equipment/equipment.js',
      'to' => 'custom/modules/Contacts/clients/base/fields/equipment/equipment.js',
    ),
    38 => 
    array (
      'from' => '<basepath>/src/custom/modules/Leads/clients/base/views/equip-powers/equip-powers.hbs',
      'to' => 'custom/modules/Leads/clients/base/views/equip-powers/equip-powers.hbs',
    ),
    39 => 
    array (
      'from' => '<basepath>/src/custom/modules/Leads/clients/base/views/equip-powers/equip-powers.js',
      'to' => 'custom/modules/Leads/clients/base/views/equip-powers/equip-powers.js',
    ),
    40 => 
    array (
      'from' => '<basepath>/src/custom/modules/Leads/clients/base/views/equip-powers/equip-powers.php',
      'to' => 'custom/modules/Leads/clients/base/views/equip-powers/equip-powers.php',
    ),
    41 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/filters/basic/basic.php',
      'to' => 'modules/msgc_Equipment/clients/base/filters/basic/basic.php',
    ),
    42 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/filters/default/default.php',
      'to' => 'modules/msgc_Equipment/clients/base/filters/default/default.php',
    ),
    43 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/menus/header/header.php',
      'to' => 'modules/msgc_Equipment/clients/base/menus/header/header.php',
    ),
    44 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/menus/quickcreate/quickcreate.php',
      'to' => 'modules/msgc_Equipment/clients/base/menus/quickcreate/quickcreate.php',
    ),
    45 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/views/dupecheck-list/dupecheck-list.php',
      'to' => 'modules/msgc_Equipment/clients/base/views/dupecheck-list/dupecheck-list.php',
    ),
    46 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/views/list/list.php',
      'to' => 'modules/msgc_Equipment/clients/base/views/list/list.php',
    ),
    47 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/views/massupdate/massupdate.php',
      'to' => 'modules/msgc_Equipment/clients/base/views/massupdate/massupdate.php',
    ),
    48 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/views/record/record.php',
      'to' => 'modules/msgc_Equipment/clients/base/views/record/record.php',
    ),
    49 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/views/search-list/search-list.php',
      'to' => 'modules/msgc_Equipment/clients/base/views/search-list/search-list.php',
    ),
    50 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/views/selection-list/selection-list.php',
      'to' => 'modules/msgc_Equipment/clients/base/views/selection-list/selection-list.php',
    ),
    51 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/base/views/subpanel-list/subpanel-list.php',
      'to' => 'modules/msgc_Equipment/clients/base/views/subpanel-list/subpanel-list.php',
    ),
    52 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/mobile/layouts/detail/detail.php',
      'to' => 'modules/msgc_Equipment/clients/mobile/layouts/detail/detail.php',
    ),
    53 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/mobile/layouts/edit/edit.php',
      'to' => 'modules/msgc_Equipment/clients/mobile/layouts/edit/edit.php',
    ),
    54 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/mobile/layouts/list/list.php',
      'to' => 'modules/msgc_Equipment/clients/mobile/layouts/list/list.php',
    ),
    55 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/mobile/views/detail/detail.php',
      'to' => 'modules/msgc_Equipment/clients/mobile/views/detail/detail.php',
    ),
    56 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/mobile/views/edit/edit.php',
      'to' => 'modules/msgc_Equipment/clients/mobile/views/edit/edit.php',
    ),
    57 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/clients/mobile/views/list/list.php',
      'to' => 'modules/msgc_Equipment/clients/mobile/views/list/list.php',
    ),
    58 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/Dashlets/msgc_EquipmentDashlet/msgc_EquipmentDashlet.meta.php',
      'to' => 'modules/msgc_Equipment/Dashlets/msgc_EquipmentDashlet/msgc_EquipmentDashlet.meta.php',
    ),
    59 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/Dashlets/msgc_EquipmentDashlet/msgc_EquipmentDashlet.php',
      'to' => 'modules/msgc_Equipment/Dashlets/msgc_EquipmentDashlet/msgc_EquipmentDashlet.php',
    ),
    60 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/language/en_us.lang.php',
      'to' => 'modules/msgc_Equipment/language/en_us.lang.php',
    ),
    61 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/dashletviewdefs.php',
      'to' => 'modules/msgc_Equipment/metadata/dashletviewdefs.php',
    ),
    62 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/detailviewdefs.php',
      'to' => 'modules/msgc_Equipment/metadata/detailviewdefs.php',
    ),
    63 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/editviewdefs.php',
      'to' => 'modules/msgc_Equipment/metadata/editviewdefs.php',
    ),
    64 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/listviewdefs.php',
      'to' => 'modules/msgc_Equipment/metadata/listviewdefs.php',
    ),
    65 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/metafiles.php',
      'to' => 'modules/msgc_Equipment/metadata/metafiles.php',
    ),
    66 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/popupdefs.php',
      'to' => 'modules/msgc_Equipment/metadata/popupdefs.php',
    ),
    67 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/quickcreatedefs.php',
      'to' => 'modules/msgc_Equipment/metadata/quickcreatedefs.php',
    ),
    68 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/searchdefs.php',
      'to' => 'modules/msgc_Equipment/metadata/searchdefs.php',
    ),
    69 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/SearchFields.php',
      'to' => 'modules/msgc_Equipment/metadata/SearchFields.php',
    ),
    70 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/studio.php',
      'to' => 'modules/msgc_Equipment/metadata/studio.php',
    ),
    71 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/metadata/subpanels/default.php',
      'to' => 'modules/msgc_Equipment/metadata/subpanels/default.php',
    ),
    72 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/msgc_Equipment.php',
      'to' => 'modules/msgc_Equipment/msgc_Equipment.php',
    ),
    73 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/msgc_Equipment_sugar.php',
      'to' => 'modules/msgc_Equipment/msgc_Equipment_sugar.php',
    ),
    74 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Equipment/vardefs.php',
      'to' => 'modules/msgc_Equipment/vardefs.php',
    ),
    75 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/filters/basic/basic.php',
      'to' => 'modules/msgc_Powers/clients/base/filters/basic/basic.php',
    ),
    76 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/filters/default/default.php',
      'to' => 'modules/msgc_Powers/clients/base/filters/default/default.php',
    ),
    77 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/menus/header/header.php',
      'to' => 'modules/msgc_Powers/clients/base/menus/header/header.php',
    ),
    78 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/menus/quickcreate/quickcreate.php',
      'to' => 'modules/msgc_Powers/clients/base/menus/quickcreate/quickcreate.php',
    ),
    79 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/views/dupecheck-list/dupecheck-list.php',
      'to' => 'modules/msgc_Powers/clients/base/views/dupecheck-list/dupecheck-list.php',
    ),
    80 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/views/list/list.php',
      'to' => 'modules/msgc_Powers/clients/base/views/list/list.php',
    ),
    81 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/views/massupdate/massupdate.php',
      'to' => 'modules/msgc_Powers/clients/base/views/massupdate/massupdate.php',
    ),
    82 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/views/record/record.php',
      'to' => 'modules/msgc_Powers/clients/base/views/record/record.php',
    ),
    83 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/views/search-list/search-list.php',
      'to' => 'modules/msgc_Powers/clients/base/views/search-list/search-list.php',
    ),
    84 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/views/selection-list/selection-list.php',
      'to' => 'modules/msgc_Powers/clients/base/views/selection-list/selection-list.php',
    ),
    85 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/base/views/subpanel-list/subpanel-list.php',
      'to' => 'modules/msgc_Powers/clients/base/views/subpanel-list/subpanel-list.php',
    ),
    86 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/mobile/layouts/detail/detail.php',
      'to' => 'modules/msgc_Powers/clients/mobile/layouts/detail/detail.php',
    ),
    87 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/mobile/layouts/edit/edit.php',
      'to' => 'modules/msgc_Powers/clients/mobile/layouts/edit/edit.php',
    ),
    88 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/mobile/layouts/list/list.php',
      'to' => 'modules/msgc_Powers/clients/mobile/layouts/list/list.php',
    ),
    89 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/mobile/views/detail/detail.php',
      'to' => 'modules/msgc_Powers/clients/mobile/views/detail/detail.php',
    ),
    90 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/mobile/views/edit/edit.php',
      'to' => 'modules/msgc_Powers/clients/mobile/views/edit/edit.php',
    ),
    91 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/clients/mobile/views/list/list.php',
      'to' => 'modules/msgc_Powers/clients/mobile/views/list/list.php',
    ),
    92 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/Dashlets/msgc_PowersDashlet/msgc_PowersDashlet.meta.php',
      'to' => 'modules/msgc_Powers/Dashlets/msgc_PowersDashlet/msgc_PowersDashlet.meta.php',
    ),
    93 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/Dashlets/msgc_PowersDashlet/msgc_PowersDashlet.php',
      'to' => 'modules/msgc_Powers/Dashlets/msgc_PowersDashlet/msgc_PowersDashlet.php',
    ),
    94 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/language/en_us.lang.php',
      'to' => 'modules/msgc_Powers/language/en_us.lang.php',
    ),
    95 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/dashletviewdefs.php',
      'to' => 'modules/msgc_Powers/metadata/dashletviewdefs.php',
    ),
    96 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/detailviewdefs.php',
      'to' => 'modules/msgc_Powers/metadata/detailviewdefs.php',
    ),
    97 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/editviewdefs.php',
      'to' => 'modules/msgc_Powers/metadata/editviewdefs.php',
    ),
    98 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/listviewdefs.php',
      'to' => 'modules/msgc_Powers/metadata/listviewdefs.php',
    ),
    99 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/metafiles.php',
      'to' => 'modules/msgc_Powers/metadata/metafiles.php',
    ),
    100 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/popupdefs.php',
      'to' => 'modules/msgc_Powers/metadata/popupdefs.php',
    ),
    101 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/quickcreatedefs.php',
      'to' => 'modules/msgc_Powers/metadata/quickcreatedefs.php',
    ),
    102 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/searchdefs.php',
      'to' => 'modules/msgc_Powers/metadata/searchdefs.php',
    ),
    103 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/SearchFields.php',
      'to' => 'modules/msgc_Powers/metadata/SearchFields.php',
    ),
    104 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/studio.php',
      'to' => 'modules/msgc_Powers/metadata/studio.php',
    ),
    105 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/metadata/subpanels/default.php',
      'to' => 'modules/msgc_Powers/metadata/subpanels/default.php',
    ),
    106 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/msgc_Powers.php',
      'to' => 'modules/msgc_Powers/msgc_Powers.php',
    ),
    107 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/msgc_Powers_sugar.php',
      'to' => 'modules/msgc_Powers/msgc_Powers_sugar.php',
    ),
    108 => 
    array (
      'from' => '<basepath>/src/modules/msgc_Powers/vardefs.php',
      'to' => 'modules/msgc_Powers/vardefs.php',
    ),
  ),
);
