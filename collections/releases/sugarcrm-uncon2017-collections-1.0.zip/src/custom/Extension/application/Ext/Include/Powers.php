<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['msgc_Powers'] = 'msgc_Powers';
$beanFiles['msgc_Powers'] = 'modules/msgc_Powers/msgc_Powers.php';
$moduleList[] = 'msgc_Powers';

?>