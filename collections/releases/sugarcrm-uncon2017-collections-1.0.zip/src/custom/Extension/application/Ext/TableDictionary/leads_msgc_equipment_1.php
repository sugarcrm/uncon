<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/leads_msgc_equipment_1MetaData.php');

?>