<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['msgc_Equipment'] = 'msgc_Equipment';
$beanFiles['msgc_Equipment'] = 'modules/msgc_Equipment/msgc_Equipment.php';
$moduleList[] = 'msgc_Equipment';

?>