<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/msgc_equipment_contactsMetaData.php');

?>