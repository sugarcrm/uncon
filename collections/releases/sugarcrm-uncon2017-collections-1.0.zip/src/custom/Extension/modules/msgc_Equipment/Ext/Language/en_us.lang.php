<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_MSGC_EQUIPMENT_CONTACTS_FROM_CONTACTS_TITLE'] = 'Heroes';
