<?php
// created: 2017-09-07 19:15:30
$dictionary["msgc_Equipment"]["fields"]["leads_msgc_equipment_1"] = array (
  'name' => 'leads_msgc_equipment_1',
  'type' => 'link',
  'relationship' => 'leads_msgc_equipment_1',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_LEADS_MSGC_EQUIPMENT_1_FROM_LEADS_TITLE',
  'id_name' => 'leads_msgc_equipment_1leads_ida',
);
