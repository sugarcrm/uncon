<?php
// created: 2017-09-07 01:55:14
$dictionary["msgc_Equipment"]["fields"]["msgc_equipment_contacts"] = array (
  'name' => 'msgc_equipment_contacts',
  'type' => 'link',
  'relationship' => 'msgc_equipment_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_MSGC_EQUIPMENT_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'msgc_equipment_contactscontacts_idb',
);
