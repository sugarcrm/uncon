<?php
// created: 2017-09-07 01:55:14
$viewdefs['msgc_Equipment']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MSGC_EQUIPMENT_CONTACTS_FROM_CONTACTS_TITLE',
  'context' => 
  array (
    'link' => 'msgc_equipment_contacts',
  ),
);