<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/msgc_Equipment/Ext/Language/en_us.customleads_msgc_equipment_1.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_LEADS_MSGC_EQUIPMENT_1_FROM_LEADS_TITLE'] = 'Leads';
$mod_strings['LBL_LEADS_MSGC_EQUIPMENT_1_FROM_MSGC_EQUIPMENT_TITLE'] = 'Leads';

?>
<?php
// Merged from custom/Extension/modules/msgc_Equipment/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_LEADS_MSGC_EQUIPMENT_1_FROM_LEADS_TITLE'] = 'Leads';
$mod_strings['LBL_LEADS_MSGC_EQUIPMENT_1_FROM_MSGC_EQUIPMENT_TITLE'] = 'Leads';

?>
