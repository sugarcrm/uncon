<?php
// created: 2017-09-07 19:15:30
$viewdefs['msgc_Equipment']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEADS_MSGC_EQUIPMENT_1_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'leads_msgc_equipment_1',
  ),
);