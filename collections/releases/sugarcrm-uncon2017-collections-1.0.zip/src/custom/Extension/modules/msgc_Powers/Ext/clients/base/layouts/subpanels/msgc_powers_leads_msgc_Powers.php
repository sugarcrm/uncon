<?php
// created: 2017-09-07 19:19:11
$viewdefs['msgc_Powers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MSGC_POWERS_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'msgc_powers_leads',
  ),
);

$viewdefs['msgc_Powers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MSGC_POWERS_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'msgc_powers_leads',
  ),
);

$viewdefs['msgc_Powers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MSGC_POWERS_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'msgc_powers_leads',
  ),
);

$viewdefs['msgc_Powers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MSGC_POWERS_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'msgc_powers_leads',
  ),
);

$viewdefs['msgc_Powers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MSGC_POWERS_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'msgc_powers_leads',
  ),
);

$viewdefs['msgc_Powers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MSGC_POWERS_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'msgc_powers_leads',
  ),
);

$viewdefs['msgc_Powers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MSGC_POWERS_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'msgc_powers_leads',
  ),
);

$viewdefs['msgc_Powers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MSGC_POWERS_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'msgc_powers_leads',
  ),
);