<?php
// created: 2017-09-07 19:31:07
$dictionary["msgc_Powers"]["fields"]["msgc_powers_leads"] = array (
  'name' => 'msgc_powers_leads',
  'type' => 'link',
  'relationship' => 'msgc_powers_leads',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_MSGC_POWERS_LEADS_FROM_LEADS_TITLE',
  'id_name' => 'msgc_powers_leadsleads_idb',
);
