<?php
// created: 2017-09-07 19:15:30
$dictionary["Lead"]["fields"]["leads_msgc_equipment_1"] = array (
  'name' => 'leads_msgc_equipment_1',
  'type' => 'link',
  'relationship' => 'leads_msgc_equipment_1',
  'source' => 'non-db',
  'module' => 'msgc_Equipment',
  'bean_name' => 'msgc_Equipment',
  'vname' => 'LBL_LEADS_MSGC_EQUIPMENT_1_FROM_MSGC_EQUIPMENT_TITLE',
  'id_name' => 'leads_msgc_equipment_1msgc_equipment_idb',
);
