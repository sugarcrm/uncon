<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Leads/Ext/Language/en_us.customleads_msgc_equipment_1.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_LEADS_MSGC_EQUIPMENT_1_FROM_MSGC_EQUIPMENT_TITLE'] = 'Equipment';
$mod_strings['LBL_LEADS_MSGC_EQUIPMENT_1_FROM_LEADS_TITLE'] = 'Equipment';

?>
<?php
// Merged from custom/Extension/modules/Leads/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_LEADS_MSGC_EQUIPMENT_1_FROM_MSGC_EQUIPMENT_TITLE'] = 'Equipment';
$mod_strings['LBL_LEADS_MSGC_EQUIPMENT_1_FROM_LEADS_TITLE'] = 'Equipment';

?>
