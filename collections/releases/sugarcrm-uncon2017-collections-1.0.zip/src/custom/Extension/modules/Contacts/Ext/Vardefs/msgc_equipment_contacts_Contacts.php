<?php
// created: 2017-09-07 01:55:14
$dictionary["Contact"]["fields"]["msgc_equipment_contacts"] = array (
  'name' => 'msgc_equipment_contacts',
  'type' => 'link',
  'relationship' => 'msgc_equipment_contacts',
  'source' => 'non-db',
  'module' => 'msgc_Equipment',
  'bean_name' => 'msgc_Equipment',
  'vname' => 'LBL_MSGC_EQUIPMENT_CONTACTS_FROM_MSGC_EQUIPMENT_TITLE',
  'id_name' => 'msgc_equipment_contactsmsgc_equipment_ida',
);
