<?php
 // created: 2015-04-17 15:49:16
$dictionary['Account']['fields']['lat_long_c']['labelValue']='Location';
$dictionary['Account']['fields']['lat_long_c']['full_text_search']=array (
  'boost' => '1',
  'enabled' => true,
);
$dictionary['Account']['fields']['lat_long_c']['enforced']='';
$dictionary['Account']['fields']['lat_long_c']['dependency']='';
