<?php
$manifest = array (
  'id' => 'scon15-elastic-file-indexing-1.0',
  'name' => 'SugarCon 2015 Elastichsearch File Indexing POC',
  'description' => 'SugarCon 2015 Elastichsearch File Indexing POC',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2015-04-20 02:05:07',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '7.7.0.0',
    ),
    'regex_matches' => 
    array (
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Documents/Ext/Vardefs/elasticsearch_filecontent.php',
      'to' => 'custom/Extension/modules/Documents/Ext/Vardefs/elasticsearch_filecontent.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Notes/Ext/Vardefs/elasticsearch_filecontent.php',
      'to' => 'custom/Extension/modules/Notes/Ext/Vardefs/elasticsearch_filecontent.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Utils/ElasticsearchFileHandler.php',
      'to' => 'custom/Extension/application/Ext/Utils/ElasticsearchFileHandler.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/custom/src/Elasticsearch/Provider/GlobalSearch/Handler/Implement/FileHandler.php',
      'to' => 'custom/Elasticsearch/Provider/GlobalSearch/Handler/Implement/FileHandler.php',
    ),
  ),
);
