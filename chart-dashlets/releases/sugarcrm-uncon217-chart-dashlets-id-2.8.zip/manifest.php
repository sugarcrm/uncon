<?php
$manifest = array (
  'id' => 'uncon217-chart-dashlets-id',
  'name' => 'UnCon 2017 - Building your first Chart Dashlet',
  'description' => 'UnCon 2017 - Building your first Chart Dashlet',
  'version' => '2.8',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2017-09-12 11:33:32',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.9.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/.DS_Store',
      'to' => '.DS_Store',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/.DS_Store',
      'to' => 'custom/.DS_Store',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/clients/.DS_Store',
      'to' => 'custom/clients/.DS_Store',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/.DS_Store',
      'to' => 'custom/clients/base/.DS_Store',
    ),
    4 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/.DS_Store',
      'to' => 'custom/clients/base/views/.DS_Store',
    ),
    5 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-1/ratings-chart-1.hbs',
      'to' => 'custom/clients/base/views/ratings-chart-1/ratings-chart-1.hbs',
    ),
    6 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-1/ratings-chart-1.js',
      'to' => 'custom/clients/base/views/ratings-chart-1/ratings-chart-1.js',
    ),
    7 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-1/ratings-chart-1.php',
      'to' => 'custom/clients/base/views/ratings-chart-1/ratings-chart-1.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-2/ratings-chart-2.hbs',
      'to' => 'custom/clients/base/views/ratings-chart-2/ratings-chart-2.hbs',
    ),
    9 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-2/ratings-chart-2.js',
      'to' => 'custom/clients/base/views/ratings-chart-2/ratings-chart-2.js',
    ),
    10 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-2/ratings-chart-2.php',
      'to' => 'custom/clients/base/views/ratings-chart-2/ratings-chart-2.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-3/ratings-chart-3.hbs',
      'to' => 'custom/clients/base/views/ratings-chart-3/ratings-chart-3.hbs',
    ),
    12 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-3/ratings-chart-3.js',
      'to' => 'custom/clients/base/views/ratings-chart-3/ratings-chart-3.js',
    ),
    13 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-3/ratings-chart-3.php',
      'to' => 'custom/clients/base/views/ratings-chart-3/ratings-chart-3.php',
    ),
    14 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-4/ratings-chart-4.hbs',
      'to' => 'custom/clients/base/views/ratings-chart-4/ratings-chart-4.hbs',
    ),
    15 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-4/ratings-chart-4.js',
      'to' => 'custom/clients/base/views/ratings-chart-4/ratings-chart-4.js',
    ),
    16 => 
    array (
      'from' => '<basepath>/src/custom/clients/base/views/ratings-chart-4/ratings-chart-4.php',
      'to' => 'custom/clients/base/views/ratings-chart-4/ratings-chart-4.php',
    ),
  ),
);
