<?php
$manifest = array (
  'id' => 'SugarCLI_QuickRepair',
  'name' => 'SugarCRM CLI Framework - Quick Repair command (example) ',
  'description' => 'SugarCRM CLI Framework - Quick Repair command (example) ',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2016-06-10 18:25:48',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.7.[1-9].[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/commands/QuickRepairCommand.php',
      'to' => 'custom/commands/QuickRepairCommand.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Console/qrr_cli.php',
      'to' => 'custom/Extension/application/Ext/Console/qrr_cli.php',
    ),
  ),
);
