<?php
$manifest = array (
  'id' => 'uncon16-elastic-attachments',
  'name' => 'UnCon 2016 Elasticsearch File Attachments',
  'description' => 'UnCon 2016 Elasticsearch File Attachments',
  'version' => '2.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2016-06-12 08:58:11',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.7.[1-9]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Documents/Ext/Vardefs/elasticsearch_filecontent.php',
      'to' => 'custom/Extension/modules/Documents/Ext/Vardefs/elasticsearch_filecontent.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Notes/Ext/Vardefs/elasticsearch_filecontent.php',
      'to' => 'custom/Extension/modules/Notes/Ext/Vardefs/elasticsearch_filecontent.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Utils/ElasticsearchFileHandler.php',
      'to' => 'custom/Extension/application/Ext/Utils/ElasticsearchFileHandler.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/custom/src/Elasticsearch/Provider/GlobalSearch/Handler/Implement/FileHandler.php',
      'to' => 'custom/src/Elasticsearch/Provider/GlobalSearch/Handler/Implement/FileHandler.php',
    ),
  ),
);
