<?php
$manifest = array (
  'id' => 'uncon2017-elastic-deepdive-710',
  'name' => 'UnCon 2017 Elasticsearch Deepdive for 7.10 with ES 5.4 support',
  'description' => 'UnCon 2017 Elasticsearch Deepdive for 7.10 with ES 5.4 support',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2017-08-28 07:53:08',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.10.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/modules/Accounts/clients/base/api/CustomAccountsApi.php',
      'to' => 'custom/modules/Accounts/clients/base/api/CustomAccountsApi.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Utils/ElasticAsciiFoldingHandler.php',
      'to' => 'custom/Extension/application/Ext/Utils/ElasticAsciiFoldingHandler.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Utils/ElasticDataAnalyticsProvider.php',
      'to' => 'custom/Extension/application/Ext/Utils/ElasticDataAnalyticsProvider.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/custom/src/Elasticsearch/Provider/DataAnalytics/AggQueryBuilder.php',
      'to' => 'custom/src/Elasticsearch/Provider/DataAnalytics/AggQueryBuilder.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/src/custom/src/Elasticsearch/Provider/DataAnalytics/DataAnalytics.php',
      'to' => 'custom/src/Elasticsearch/Provider/DataAnalytics/DataAnalytics.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/src/custom/src/Elasticsearch/Provider/GlobalSearch/AsciiFolding/AsciiFoldingHandler.php',
      'to' => 'custom/src/Elasticsearch/Provider/GlobalSearch/AsciiFolding/AsciiFoldingHandler.php',
    ),
    6 => 
    array (
      'from' => '<basepath>/src/custom/src/Elasticsearch/Analysis/AnalysisBuilderInjector.php',
      'to' => 'custom/src/Elasticsearch/Analysis/AnalysisBuilderInjector.php',
    ),
  ),
);
