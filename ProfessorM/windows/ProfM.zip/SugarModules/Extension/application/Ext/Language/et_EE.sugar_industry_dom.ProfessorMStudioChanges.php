<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Rõivad',
  'Banking' => 'Pangandus',
  'Biotechnology' => 'Biotehnoloogia',
  'Chemicals' => 'Kemikaalid',
  'Communications' => 'Side',
  'Construction' => 'Ehitus',
  'Consulting' => 'Konsulteerimine',
  'Education' => 'Haridus',
  'Electronics' => 'Elektroonika',
  'Energy' => 'Energia',
  'Engineering' => 'Inseneriteadus',
  'Entertainment' => 'Meelelahutus',
  'Other' => 'Muud',
);