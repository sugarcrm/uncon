<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'النسيج',
  'Banking' => 'الأعمال المصرفية',
  'Biotechnology' => 'التكنولوجيا الحيوية',
  'Chemicals' => 'المواد الكيماوية',
  'Communications' => 'الاتصالات',
  'Construction' => 'المقاولات',
  'Consulting' => 'الاستشارة',
  'Education' => 'التعليم',
  'Electronics' => 'الإلكترونيات',
  'Energy' => 'الطاقة',
  'Engineering' => 'الهندسة',
  'Entertainment' => 'التسلية',
  'Other' => 'أخرى',
);