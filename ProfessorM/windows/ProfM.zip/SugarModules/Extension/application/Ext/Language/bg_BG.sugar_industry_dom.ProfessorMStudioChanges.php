<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Текстилна промишленост',
  'Banking' => 'Банково дело',
  'Biotechnology' => 'Биотехнологии',
  'Chemicals' => 'Химическа промишленост',
  'Communications' => 'Комуникации',
  'Construction' => 'Строителство',
  'Consulting' => 'Консултантски услуги',
  'Education' => 'Образование',
  'Electronics' => 'Електроника',
  'Energy' => 'Природни ресурси и енергия',
  'Engineering' => 'Инженерна дейност',
  'Entertainment' => 'Забавление',
  'Other' => 'Други',
);