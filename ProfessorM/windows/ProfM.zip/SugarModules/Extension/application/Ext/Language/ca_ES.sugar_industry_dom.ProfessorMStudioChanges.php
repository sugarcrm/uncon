<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Tèxtil',
  'Banking' => 'Banca',
  'Biotechnology' => 'Biotecnologia',
  'Chemicals' => 'Química',
  'Communications' => 'Comunicacions',
  'Construction' => 'Construcció',
  'Consulting' => 'Consultoria',
  'Education' => 'Educació',
  'Electronics' => 'Electrònica',
  'Energy' => 'Energia',
  'Engineering' => 'Enginyeria',
  'Entertainment' => 'Entreteniment',
  'Other' => 'Un altre',
);