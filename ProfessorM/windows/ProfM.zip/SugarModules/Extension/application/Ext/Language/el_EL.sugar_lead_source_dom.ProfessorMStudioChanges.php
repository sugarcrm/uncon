<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Ψυχρό Τηλεφώνημα',
  'Existing Customer' => 'Δυνητικό Πελάτη',
  'Self Generated' => 'Αυτο-παραγόμενο',
  'Employee' => 'Εργαζόμενος',
  'Partner' => 'Συνεργάτης',
  'Public Relations' => 'Δημόσιες Σχέσεις',
  'Direct Mail' => 'Άμεση Αλληλογραφία',
  'Web Site' => 'Ιστοσελίδα',
  'Word of mouth' => 'Από στόμα σε στόμα',
  'Campaign' => 'Εκστρατεία',
  'Other' => 'Άλλο:',
);