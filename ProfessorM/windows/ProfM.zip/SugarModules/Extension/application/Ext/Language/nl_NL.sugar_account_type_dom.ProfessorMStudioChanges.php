<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analist',
  'Competitor' => 'Concurrent',
  'Customer' => 'Klant',
  'Integrator' => 'Integreerder',
  'Other' => 'Anders',
);