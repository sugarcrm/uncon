<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Kaltakquise',
  'Existing Customer' => 'Bestehender Kunde',
  'Self Generated' => 'Selbst generiert',
  'Employee' => 'Mitarbeiter',
  'Partner' => 'Partner',
  'Public Relations' => 'Public Relations',
  'Direct Mail' => 'Aussendung',
  'Web Site' => 'Webseite',
  'Word of mouth' => 'Mund zu Mund-Propaganda',
  'Campaign' => 'Kampagne',
  'Other' => 'Andere',
);