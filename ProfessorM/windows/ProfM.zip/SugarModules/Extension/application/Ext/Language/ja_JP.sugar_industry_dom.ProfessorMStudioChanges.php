<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'アパレル',
  'Banking' => '銀行業',
  'Biotechnology' => 'バイオテクノロジー',
  'Chemicals' => '化学薬品',
  'Communications' => '通信',
  'Construction' => '建設',
  'Consulting' => 'コンサルティング',
  'Education' => '教育',
  'Electronics' => '電子機器',
  'Energy' => 'エネルギー',
  'Engineering' => '工学',
  'Entertainment' => '娯楽',
  'Other' => 'その他',
);