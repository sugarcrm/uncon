<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Külm kõne',
  'Existing Customer' => 'Olemasolev klient',
  'Self Generated' => 'Ise loodud',
  'Employee' => 'Töötaja',
  'Partner' => 'Partner',
  'Public Relations' => 'Avalikud suhted',
  'Direct Mail' => 'Otsepost',
  'Web Site' => 'Veebisait',
  'Word of mouth' => 'Suusõnaline teade',
  'Campaign' => 'Kampaania',
  'Other' => 'Muud',
);