<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Beklædning',
  'Banking' => 'Bank',
  'Biotechnology' => 'Bioteknologi',
  'Chemicals' => 'Kemikalier',
  'Communications' => 'Kommunikation',
  'Construction' => 'Byggeri',
  'Consulting' => 'Rådgivning',
  'Education' => 'Uddannelse',
  'Electronics' => 'Elektronik',
  'Energy' => 'Energi',
  'Engineering' => 'Teknik',
  'Entertainment' => 'Underholdning',
  'Other' => 'Andet',
);