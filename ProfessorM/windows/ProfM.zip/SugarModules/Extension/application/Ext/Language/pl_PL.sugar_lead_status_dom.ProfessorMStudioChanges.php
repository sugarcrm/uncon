<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Nowy',
  'Assigned' => 'Przydzielono',
  'In Process' => 'W trakcie',
  'Converted' => 'Przekształcony',
  'Recycled' => 'Odzyskany',
  'Dead' => 'Utracony',
);