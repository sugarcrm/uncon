<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analitikas',
  'Competitor' => 'Konkurentas',
  'Customer' => 'Klientas',
  'Integrator' => 'Integruotojas',
  'Other' => 'Kita',
);