<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Drabužiai',
  'Banking' => 'Bankininkystė',
  'Biotechnology' => 'Biotechnologijos',
  'Chemicals' => 'Chemikalai',
  'Communications' => 'Ryšiai',
  'Construction' => 'Statyba',
  'Consulting' => 'Konsultavimas',
  'Education' => 'Švietimas',
  'Electronics' => 'Elektronika',
  'Energy' => 'Energetika',
  'Engineering' => 'Inžinerija',
  'Entertainment' => 'Pramogos',
  'Other' => 'Kita',
);