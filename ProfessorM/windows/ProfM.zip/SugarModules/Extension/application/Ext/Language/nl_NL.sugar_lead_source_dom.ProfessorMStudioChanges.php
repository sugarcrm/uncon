<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Cold Call',
  'Existing Customer' => 'Bestaande klant',
  'Self Generated' => 'Zelf gegenereerd',
  'Employee' => 'Medewerker',
  'Partner' => 'Partner',
  'Public Relations' => 'Public Relations',
  'Direct Mail' => 'Direct mail',
  'Web Site' => 'Website',
  'Word of mouth' => 'Mond tot mond',
  'Campaign' => 'Campagne',
  'Other' => 'Anders',
);