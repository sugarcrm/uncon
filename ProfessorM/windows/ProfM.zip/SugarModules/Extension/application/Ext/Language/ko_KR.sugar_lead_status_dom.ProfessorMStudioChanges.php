<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => '신규',
  'Assigned' => '배정완료',
  'In Process' => '진행중',
  'Converted' => '변환됨',
  'Recycled' => '재할당',
  'Dead' => '만료됨',
);