<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Телефонен разговор',
  'Existing Customer' => 'Съществуващ клиент',
  'Self Generated' => 'По инициатива на клиента',
  'Employee' => 'Служител',
  'Partner' => 'Партньор',
  'Public Relations' => 'Връзки с обществеността',
  'Direct Mail' => 'Стационарна поща',
  'Web Site' => 'Сайт на компанията',
  'Word of mouth' => 'Препоръка',
  'Campaign' => 'Кампания',
  'Other' => 'Други',
);