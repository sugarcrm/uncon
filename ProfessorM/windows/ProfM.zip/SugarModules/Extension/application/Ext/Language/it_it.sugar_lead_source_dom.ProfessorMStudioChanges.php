<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Chiamata a Freddo',
  'Existing Customer' => 'Cliente Esistente',
  'Self Generated' => 'Auto-generato',
  'Employee' => 'Dipendente',
  'Partner' => 'Partner',
  'Public Relations' => 'Pubbliche Relazioni',
  'Direct Mail' => 'Direct Mailing',
  'Web Site' => 'Sito Web',
  'Word of mouth' => 'Passaparola',
  'Campaign' => 'Campagna',
  'Other' => 'Altro',
);