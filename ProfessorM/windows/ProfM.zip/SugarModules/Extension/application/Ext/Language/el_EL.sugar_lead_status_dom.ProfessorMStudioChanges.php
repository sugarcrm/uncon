<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Νέα',
  'Assigned' => 'Ανατέθηκε',
  'In Process' => 'Σε Εξέλιξη',
  'Converted' => 'Μετατράπηκε',
  'Recycled' => 'Ανακυκλώθηκε',
  'Dead' => 'Νεκρό',
);