<?php 
$app_list_strings['prof_status_list'] = array (
  'Hired' => 'Hired',
  'Active' => 'Active',
  'Leave' => 'On Leave',
  'Sabbatical' => 'Sabbatical',
  'Retired' => 'Retired',
  'Abdicated' => 'Abdicated',
  'Terminated' => 'Terminated',
  'Other' => 'Other',
);