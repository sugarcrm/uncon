<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Cold call',
  'Existing Customer' => 'Eksisterende kunde',
  'Self Generated' => 'Selv-generert',
  'Employee' => 'Medarbeider',
  'Partner' => 'Partner',
  'Public Relations' => 'PR',
  'Direct Mail' => 'Direktepost',
  'Web Site' => 'Webside',
  'Word of mouth' => 'Jungeltelegrafen',
  'Campaign' => 'Kampanje',
  'Other' => 'Andre',
);