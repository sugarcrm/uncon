<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Textile',
  'Banking' => 'Banque',
  'Biotechnology' => 'Biotechnologie',
  'Chemicals' => 'Industrie Chimique',
  'Communications' => 'Communications',
  'Construction' => 'Construction',
  'Consulting' => 'Conseil',
  'Education' => 'Éducation',
  'Electronics' => 'Informatique - Électronique',
  'Energy' => 'Énergie',
  'Engineering' => 'Ingénierie',
  'Entertainment' => 'Culture-Presse',
  'Other' => 'Autre',
);