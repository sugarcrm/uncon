<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analyst',
  'Competitor' => 'Competitor',
  'Customer' => 'Customer',
  'Integrator' => 'Integrator',
  'Other' => 'Other',
);