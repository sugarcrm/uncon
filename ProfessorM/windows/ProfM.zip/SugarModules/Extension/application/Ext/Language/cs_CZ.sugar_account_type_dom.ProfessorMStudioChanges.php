<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analytik',
  'Competitor' => 'Konkurence',
  'Customer' => 'Zákazník',
  'Integrator' => 'Integrator',
  'Other' => 'Jiné',
);