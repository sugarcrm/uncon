<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => '電話勧誘',
  'Existing Customer' => '既存の顧客',
  'Self Generated' => '自家生成',
  'Employee' => '従業員',
  'Partner' => 'パートナー',
  'Public Relations' => '広報',
  'Direct Mail' => 'ダイレクトメール',
  'Web Site' => 'ウェブサイト',
  'Word of mouth' => '口コミ',
  'Campaign' => 'キャンペーン',
  'Other' => 'その他',
);