<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Ruházat',
  'Banking' => 'Bankszektor',
  'Biotechnology' => 'Biotechnológia',
  'Chemicals' => 'Vegyipar',
  'Communications' => 'Kommunikáció',
  'Construction' => 'Építőipar',
  'Consulting' => 'Tanácsadás',
  'Education' => 'Képzés',
  'Electronics' => 'Elektronika',
  'Energy' => 'Energiaszektor',
  'Engineering' => 'Műszaki tudományok',
  'Entertainment' => 'Szórakoztatás',
  'Other' => 'Egyéb',
);