<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'New',
  'Assigned' => 'Assigned',
  'In Process' => 'In Process',
  'Converted' => 'Converted',
  'Recycled' => 'Recycled',
  'Dead' => 'Dead',
);