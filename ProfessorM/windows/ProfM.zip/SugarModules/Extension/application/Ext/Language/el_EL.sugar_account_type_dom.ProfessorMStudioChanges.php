<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Αναλυτής',
  'Competitor' => 'Ανταγωνιστής',
  'Customer' => 'Πελάτης',
  'Integrator' => 'Ολοκληρωτής',
  'Other' => 'Άλλο:',
);