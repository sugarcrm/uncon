<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Hero',
  'Competitor' => 'Villain',
  'Customer' => 'Antihero',
  'Integrator' => 'Neutral',
  'Other' => 'Other',
);