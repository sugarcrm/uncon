<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'טלמרקטינג',
  'Existing Customer' => 'לקוח קיים',
  'Self Generated' => 'נוצר בעצמו',
  'Employee' => 'עובד',
  'Partner' => 'שותף',
  'Public Relations' => 'יחסי ציבור',
  'Direct Mail' => 'דיוור ישיר',
  'Web Site' => 'אתר אינטרנט',
  'Word of mouth' => 'שמועה',
  'Campaign' => 'קמפיין',
  'Other' => 'אחר',
);