<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_REVENUELINEITEM_NAME_REVENUELINEITEM_ID'] = ' (related Funding Line Item ID)';
$mod_strings['LBL_REVENUELINEITEM_NAME'] = 'Funding Line Item Name:';
$mod_strings['LBL_CONTACT_NAME'] = 'Student Name:';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Super Group Name:';
$mod_strings['LBL_CONTACT'] = 'Student';
$mod_strings['LBL_CONTACT_ID'] = 'Student ID';
$mod_strings['LBL_ACCOUNT_ID'] = 'Super Group ID';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Super Group Name';
$mod_strings['LBL_REVENUELINEITEMS'] = 'Funding Line Items';
$mod_strings['LBL_REVENUELINEITEM_ID'] = 'Funding Line Item ID:';
$mod_strings['LBL_REVENUELINEITEM'] = 'Funding Line Item';
