<?php
$dictionary['Product']['fields']['revenuelineitems']['workflow'] = true;