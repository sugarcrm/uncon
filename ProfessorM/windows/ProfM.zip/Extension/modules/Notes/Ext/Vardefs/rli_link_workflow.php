<?php
$dictionary['Note']['fields']['revenuelineitems']['workflow'] = true;