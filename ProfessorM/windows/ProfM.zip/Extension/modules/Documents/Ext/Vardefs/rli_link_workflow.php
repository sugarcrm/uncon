<?php
$dictionary['Document']['fields']['revenuelineitems']['workflow'] = true;