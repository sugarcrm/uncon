<?php
// created: 2017-08-08 10:33:48
$dictionary["Contact"]["fields"]["pr_professors_contacts"] = array (
  'name' => 'pr_professors_contacts',
  'type' => 'link',
  'relationship' => 'pr_professors_contacts',
  'source' => 'non-db',
  'module' => 'PR_Professors',
  'bean_name' => false,
  'vname' => 'LBL_PR_PROFESSORS_CONTACTS_FROM_PR_PROFESSORS_TITLE',
  'id_name' => 'pr_professors_contactspr_professors_ida',
);
