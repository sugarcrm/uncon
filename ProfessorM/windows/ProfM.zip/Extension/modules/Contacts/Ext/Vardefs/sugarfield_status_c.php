<?php
 // created: 2017-08-07 16:24:53
$dictionary['Contact']['fields']['status_c']['labelValue']='Status';
$dictionary['Contact']['fields']['status_c']['dependency']='';
$dictionary['Contact']['fields']['status_c']['visibility_grid']='';

 ?>