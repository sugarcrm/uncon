<?php
// created: 2017-08-08 10:33:48
$dictionary["PR_Professors"]["fields"]["pr_professors_contacts"] = array (
  'name' => 'pr_professors_contacts',
  'type' => 'link',
  'relationship' => 'pr_professors_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_PR_PROFESSORS_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'pr_professors_contactscontacts_idb',
);
