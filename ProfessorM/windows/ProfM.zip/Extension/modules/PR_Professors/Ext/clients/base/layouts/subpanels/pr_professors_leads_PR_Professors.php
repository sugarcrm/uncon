<?php
// created: 2017-08-08 10:33:48
$viewdefs['PR_Professors']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PR_PROFESSORS_LEADS_FROM_LEADS_TITLE',
  'context' => 
  array (
    'link' => 'pr_professors_leads',
  ),
);