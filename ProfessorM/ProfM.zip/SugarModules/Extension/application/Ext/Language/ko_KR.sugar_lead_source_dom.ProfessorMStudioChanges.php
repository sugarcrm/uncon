<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => '방문판매',
  'Existing Customer' => '기존고객',
  'Self Generated' => '자가 생성됨',
  'Employee' => '직원',
  'Partner' => '협력자',
  'Public Relations' => '광고 및 홍보',
  'Direct Mail' => 'DM 우편',
  'Web Site' => '웹사이트',
  'Word of mouth' => '입소문',
  'Campaign' => '캠페인',
  'Other' => '기타',
);