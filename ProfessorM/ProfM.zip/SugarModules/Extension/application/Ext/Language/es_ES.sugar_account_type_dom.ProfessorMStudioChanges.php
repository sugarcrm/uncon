<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analista',
  'Competitor' => 'Competidor',
  'Customer' => 'Cliente',
  'Integrator' => 'Integrador',
  'Other' => 'Otro',
);