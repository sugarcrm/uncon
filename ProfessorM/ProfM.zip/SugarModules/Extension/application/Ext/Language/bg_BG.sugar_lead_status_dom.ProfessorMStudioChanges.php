<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Нов',
  'Assigned' => 'Разпределена',
  'In Process' => 'В опашката?',
  'Converted' => 'Преобразуван:',
  'Recycled' => 'Премахнат',
  'Dead' => 'Загубен',
);