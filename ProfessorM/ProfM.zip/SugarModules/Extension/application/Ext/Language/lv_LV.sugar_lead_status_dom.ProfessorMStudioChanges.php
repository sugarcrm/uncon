<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Jauns',
  'Assigned' => 'Nodots',
  'In Process' => 'Procesā',
  'Converted' => 'Konvertēts',
  'Recycled' => 'Atkārtotā procesā',
  'Dead' => 'Izbeigts',
);