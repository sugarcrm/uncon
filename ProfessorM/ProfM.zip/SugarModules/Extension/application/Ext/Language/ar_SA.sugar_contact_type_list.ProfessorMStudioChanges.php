<?php 
$app_list_strings['contact_type_list'] = array (
  'Prospective Student' => 'Prospective',
  'Current Student' => 'Current',
  'Past Student' => 'Former',
  'Alumnus' => 'Alumnus',
);