<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Volání naslepo',
  'Existing Customer' => 'Existujíci zákazník',
  'Self Generated' => 'Automaticky generováno',
  'Employee' => 'Zaměstnanec',
  'Partner' => 'Partner',
  'Public Relations' => 'Verejné vztahy',
  'Direct Mail' => 'Přimá pošta',
  'Web Site' => 'Webová stránka',
  'Word of mouth' => 'Z doslechu',
  'Campaign' => 'Kampaň',
  'Other' => 'Jiné',
);