<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analītiķis',
  'Competitor' => 'Konkurents',
  'Customer' => 'Klients',
  'Integrator' => 'Integrators',
  'Other' => 'Cits',
);