<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Llamada en frío',
  'Existing Customer' => 'Cliente existente',
  'Self Generated' => 'Generado automáticamente',
  'Employee' => 'Empleado',
  'Partner' => 'Colaborador',
  'Public Relations' => 'Relaciones Públicas',
  'Direct Mail' => 'Email directo',
  'Web Site' => 'Sitio Web',
  'Word of mouth' => 'Recomendación',
  'Campaign' => 'Campaña',
  'Other' => 'Otros',
);