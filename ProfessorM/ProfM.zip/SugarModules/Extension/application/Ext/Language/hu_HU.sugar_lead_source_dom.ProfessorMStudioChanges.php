<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Hideghívás',
  'Existing Customer' => 'Meglévő kliens',
  'Self Generated' => 'Önállóan létrehozott',
  'Employee' => 'Munkavállaló',
  'Partner' => 'Partner',
  'Public Relations' => 'PR',
  'Direct Mail' => 'Közvetlen email',
  'Web Site' => 'Weboldal',
  'Word of mouth' => 'Szóbeszéd',
  'Campaign' => 'Kampány',
  'Other' => 'Egyéb',
);