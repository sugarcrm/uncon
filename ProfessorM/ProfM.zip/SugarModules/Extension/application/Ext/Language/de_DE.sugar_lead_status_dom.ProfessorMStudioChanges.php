<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Neu',
  'Assigned' => 'Zugewiesen',
  'In Process' => 'In Bearbeitung',
  'Converted' => 'Konvertiert',
  'Recycled' => 'Wiedereröffnet',
  'Dead' => 'Tot',
);