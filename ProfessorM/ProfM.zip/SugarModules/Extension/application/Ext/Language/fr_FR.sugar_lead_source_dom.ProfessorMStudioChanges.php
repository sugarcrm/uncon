<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Appel à froid',
  'Existing Customer' => 'Client existant',
  'Self Generated' => 'Auto généré',
  'Employee' => 'Employé',
  'Partner' => 'Partenaire',
  'Public Relations' => 'Relation publique',
  'Direct Mail' => 'Mailing direct',
  'Web Site' => 'Site Web',
  'Word of mouth' => 'Recommandation',
  'Campaign' => 'Campagne',
  'Other' => 'Autre',
);