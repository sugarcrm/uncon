<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Nenajavljeni poziv',
  'Existing Customer' => 'Postojeći klijent',
  'Self Generated' => 'Automatski generirano',
  'Employee' => 'Zaposlenik',
  'Partner' => 'Partner',
  'Public Relations' => 'Odnosi s javnošću',
  'Direct Mail' => 'Izravna pošta',
  'Web Site' => 'Web-mjesto',
  'Word of mouth' => 'Usmeno',
  'Campaign' => 'Kampanja',
  'Other' => 'Ostalo',
);