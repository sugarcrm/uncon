<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Darījuma zvans',
  'Existing Customer' => 'Esošs klients',
  'Self Generated' => 'Pašģenerēts',
  'Employee' => 'Darbinieks',
  'Partner' => 'Partneris',
  'Public Relations' => 'Sabiedriskās attiecības',
  'Direct Mail' => 'Tiešais pasts',
  'Web Site' => 'Mājaslapa',
  'Word of mouth' => 'Mutiska rekomendācija',
  'Campaign' => 'Kampaņa',
  'Other' => 'Cits',
);