<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Têxtil',
  'Banking' => 'Banco',
  'Biotechnology' => 'Biotecnologia',
  'Chemicals' => 'Química',
  'Communications' => 'Comunicações',
  'Construction' => 'Construção',
  'Consulting' => 'Consultoria',
  'Education' => 'Educação',
  'Electronics' => 'Electrônicos',
  'Energy' => 'Energia',
  'Engineering' => 'Engenharia',
  'Entertainment' => 'Entretenimento',
  'Other' => 'Outro',
);