<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'جديد',
  'Assigned' => 'معيَّن',
  'In Process' => 'قيد التقدم',
  'Converted' => 'محول',
  'Recycled' => 'معاد تصنيعه',
  'Dead' => 'خامد',
);