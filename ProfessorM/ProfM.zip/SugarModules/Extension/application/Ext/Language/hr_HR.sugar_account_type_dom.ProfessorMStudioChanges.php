<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analitičar',
  'Competitor' => 'Konkurent',
  'Customer' => 'Klijent',
  'Integrator' => 'Integrator',
  'Other' => 'Ostalo',
);