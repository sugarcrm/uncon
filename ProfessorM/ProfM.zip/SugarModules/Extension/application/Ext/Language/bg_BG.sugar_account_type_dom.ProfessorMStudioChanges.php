<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Анализатор',
  'Competitor' => 'Конкурент',
  'Customer' => 'Клиент',
  'Integrator' => 'Интегратор',
  'Other' => 'Други',
);