<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Apparel',
  'Banking' => 'Banking',
  'Biotechnology' => 'Biotechnology',
  'Chemicals' => 'Chemicals',
  'Communications' => 'Communications',
  'Construction' => 'Construction',
  'Consulting' => 'Consulting',
  'Education' => 'Education',
  'Electronics' => 'Electronics',
  'Energy' => 'Energy',
  'Engineering' => 'Engineering',
  'Entertainment' => 'Entertainment',
  'Other' => 'Other',
);