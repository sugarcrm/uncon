<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Ny',
  'Assigned' => 'Tildelt',
  'In Process' => 'Startet',
  'Converted' => 'Konverteret',
  'Recycled' => 'Genbrugt',
  'Dead' => 'Ikke interesseret',
);