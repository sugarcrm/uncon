<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Nouveau',
  'Assigned' => 'Assigné',
  'In Process' => 'En cours',
  'Converted' => 'Converti',
  'Recycled' => 'Réactivé',
  'Dead' => 'Mort',
);