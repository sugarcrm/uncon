<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Branża odzieżowa',
  'Banking' => 'Bankowość',
  'Biotechnology' => 'Biotechnologia',
  'Chemicals' => 'Branża chemiczna',
  'Communications' => 'Komunikacja',
  'Construction' => 'Budownictwo',
  'Consulting' => 'Konsulting',
  'Education' => 'Edukacja',
  'Electronics' => 'Branża elektroniczna',
  'Energy' => 'Branża energetyczna',
  'Engineering' => 'Inżynieria',
  'Entertainment' => 'Branża rozrywkowa',
  'Other' => 'Inne',
);