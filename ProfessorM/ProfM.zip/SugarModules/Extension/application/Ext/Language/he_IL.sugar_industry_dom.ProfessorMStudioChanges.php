<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'לבוש',
  'Banking' => 'בנקאות',
  'Biotechnology' => 'ביוטק',
  'Chemicals' => 'כימיקלים',
  'Communications' => 'תקשורת',
  'Construction' => 'בנייה',
  'Consulting' => 'ייעוץ',
  'Education' => 'חינוך',
  'Electronics' => 'אלקטרוניקה',
  'Energy' => 'אנרגיה',
  'Engineering' => 'הנדסה',
  'Entertainment' => 'בידור',
  'Other' => 'אחר',
);