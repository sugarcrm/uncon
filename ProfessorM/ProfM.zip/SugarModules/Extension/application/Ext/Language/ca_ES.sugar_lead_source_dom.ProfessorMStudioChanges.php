<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Telemàrqueting',
  'Existing Customer' => 'Client existent',
  'Self Generated' => 'Autogenerat',
  'Employee' => 'Empleat',
  'Partner' => 'Soci',
  'Public Relations' => 'Relacions públiques',
  'Direct Mail' => 'Correu directe',
  'Web Site' => 'Lloc web',
  'Word of mouth' => 'Recomanació',
  'Campaign' => 'Campanya',
  'Other' => 'Un altre',
);