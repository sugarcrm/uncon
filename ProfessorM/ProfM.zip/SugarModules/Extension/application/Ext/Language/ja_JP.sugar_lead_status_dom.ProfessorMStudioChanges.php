<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => '新規',
  'Assigned' => 'アサイン済み',
  'In Process' => '進行中',
  'Converted' => 'コンバート済み',
  'Recycled' => '再利用済み',
  'Dead' => 'デッド',
);