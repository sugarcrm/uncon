<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Telemarketing',
  'Existing Customer' => 'Cliente existente',
  'Self Generated' => 'Autogerado',
  'Employee' => 'Funcionário',
  'Partner' => 'Parceiro',
  'Public Relations' => 'Relações públicas',
  'Direct Mail' => 'Mala direta',
  'Web Site' => 'Site',
  'Word of mouth' => 'Ouviu falar',
  'Campaign' => 'Campanha',
  'Other' => 'Outro',
);