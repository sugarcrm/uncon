<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Tøy',
  'Banking' => 'Banktjenester',
  'Biotechnology' => 'Bioteknologi',
  'Chemicals' => 'Kjemi',
  'Communications' => 'Kommunikasjon',
  'Construction' => 'Bygg',
  'Consulting' => 'Rådgivning',
  'Education' => 'Utdanning',
  'Electronics' => 'Elektronikk',
  'Energy' => 'Energi',
  'Engineering' => 'Ingeniør',
  'Entertainment' => 'Underholdning',
  'Other' => 'Andre',
);