<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analüütik',
  'Competitor' => 'Konkurent',
  'Customer' => 'Klient',
  'Integrator' => 'Integraator',
  'Other' => 'Muud',
);