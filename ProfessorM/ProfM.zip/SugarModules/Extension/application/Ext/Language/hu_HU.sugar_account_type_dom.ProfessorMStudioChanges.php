<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Elemző',
  'Competitor' => 'Versenytárs',
  'Customer' => 'Ügyfél',
  'Integrator' => 'Integrátor',
  'Other' => 'Egyéb',
);