<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'المحلل',
  'Competitor' => 'المنافس',
  'Customer' => 'العميل',
  'Integrator' => 'الموحد',
  'Other' => 'أخرى',
);