<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Telemarketing',
  'Existing Customer' => 'Istniejący kontrahent',
  'Self Generated' => 'Samodzielnie generowane',
  'Employee' => 'Pracownik',
  'Partner' => 'Partner',
  'Public Relations' => 'Public Relations',
  'Direct Mail' => 'Reklama bezpośrednia',
  'Web Site' => 'Strona WWW',
  'Word of mouth' => 'Polecenie',
  'Campaign' => 'Kampania',
  'Other' => 'Inne',
);