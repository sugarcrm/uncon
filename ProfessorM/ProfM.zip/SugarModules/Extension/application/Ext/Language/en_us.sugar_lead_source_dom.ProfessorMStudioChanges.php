<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Existing Customer' => 'Related to Student',
  'Employee' => 'Related to Professor',
  'Partner' => 'Cerebro',
  'Cold Call' => 'Cold Call',
  'Self Generated' => 'Self Generated',
  'Public Relations' => 'Public Outreach',
  'Direct Mail' => 'Direct Mail',
  'Web Site' => 'Web Site',
  'Word of mouth' => 'Word of mouth',
  'Campaign' => 'Campaign',
  'Other' => 'Other',
);