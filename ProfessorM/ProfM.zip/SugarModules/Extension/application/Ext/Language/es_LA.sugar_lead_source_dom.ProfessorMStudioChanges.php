<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Llamada en Frío',
  'Existing Customer' => 'Cliente Existente',
  'Self Generated' => 'Generados automáticamente',
  'Employee' => 'Empleado',
  'Partner' => 'Socio',
  'Public Relations' => 'Relaciones Públicas',
  'Direct Mail' => 'Correo Directo',
  'Web Site' => 'Sitio Web',
  'Word of mouth' => 'Recomendación',
  'Campaign' => 'Campaña',
  'Other' => 'Otro',
);