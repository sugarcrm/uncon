<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Nou',
  'Assigned' => 'Assignat',
  'In Process' => 'En Cua?',
  'Converted' => 'Convertit',
  'Recycled' => 'Reciclat',
  'Dead' => 'Mort',
);