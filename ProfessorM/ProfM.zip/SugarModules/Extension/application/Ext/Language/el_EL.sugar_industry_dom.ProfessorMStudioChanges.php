<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Ένδυση',
  'Banking' => 'Τράπεζες',
  'Biotechnology' => 'Βιοτεχνολογία',
  'Chemicals' => 'Χημικά',
  'Communications' => 'Επικοινωνίες',
  'Construction' => 'Κατασκευές',
  'Consulting' => 'Σύμβουλοι',
  'Education' => 'Εκπαίδευση',
  'Electronics' => 'Ηλεκτρονικά',
  'Energy' => 'Ενέργεια',
  'Engineering' => 'Μηχανολογικός Εξοπλισμός',
  'Entertainment' => 'Ψυχαγωγία',
  'Other' => 'Άλλο:',
);