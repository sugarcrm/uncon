<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Oblečení',
  'Banking' => 'Bankovnictví',
  'Biotechnology' => 'Biotechnologie',
  'Chemicals' => 'Chemikálie',
  'Communications' => 'Komunikace',
  'Construction' => 'Výstavba',
  'Consulting' => 'Poradenství',
  'Education' => 'Vzdělání',
  'Electronics' => 'Elektronika',
  'Energy' => 'Energie',
  'Engineering' => 'Inženýrství',
  'Entertainment' => 'Zábava',
  'Other' => 'Jiné',
);