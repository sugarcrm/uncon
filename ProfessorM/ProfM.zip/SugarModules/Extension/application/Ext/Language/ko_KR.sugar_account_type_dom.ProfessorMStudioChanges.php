<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => '분석가',
  'Competitor' => '경쟁업체',
  'Customer' => '고객',
  'Integrator' => '통합자',
  'Other' => '기타',
);