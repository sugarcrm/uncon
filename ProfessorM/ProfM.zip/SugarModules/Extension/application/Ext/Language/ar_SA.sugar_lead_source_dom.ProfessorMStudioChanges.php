<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'المكالمة التسويقية',
  'Existing Customer' => 'العميل الحالي',
  'Self Generated' => 'منشأة ذاتيًا',
  'Employee' => 'الموظف',
  'Partner' => 'شريك',
  'Public Relations' => 'العلاقات العامة',
  'Direct Mail' => 'البريد المباشر',
  'Web Site' => 'موقع الويب',
  'Word of mouth' => 'السماع',
  'Campaign' => 'الحملة',
  'Other' => 'أخرى',
);