<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Nový',
  'Assigned' => 'Přiřazeno',
  'In Process' => 'V procesu',
  'Converted' => 'Převedený',
  'Recycled' => 'Recyklován',
  'Dead' => 'Mrtvý',
);