<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Tessile',
  'Banking' => 'Bancario',
  'Biotechnology' => 'Biotecnologie',
  'Chemicals' => 'Industria Chimica',
  'Communications' => 'Comunicazioni',
  'Construction' => 'Costruzioni',
  'Consulting' => 'Consulenza',
  'Education' => 'Education',
  'Electronics' => 'Informatica - Elettronica',
  'Energy' => 'Energia',
  'Engineering' => 'Ingegneria',
  'Entertainment' => 'Intrattenimento',
  'Other' => 'Altro',
);