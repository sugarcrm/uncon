<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Uusi',
  'Assigned' => 'Määritetty:',
  'In Process' => 'Meneillään',
  'Converted' => 'Muunnettu',
  'Recycled' => 'Kierrätetty',
  'Dead' => 'Loppunut',
);