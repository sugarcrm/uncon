<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Vaatetus',
  'Banking' => 'Pankki',
  'Biotechnology' => 'Bioteknologia',
  'Chemicals' => 'Kemikaalit',
  'Communications' => 'Kommunikaatio',
  'Construction' => 'Rakentaminen',
  'Consulting' => 'Konsultointi',
  'Education' => 'Koulutus',
  'Electronics' => 'Elektroniikka',
  'Energy' => 'Energia',
  'Engineering' => 'Suunnittelu',
  'Entertainment' => 'Viihde',
  'Other' => 'Muu',
);