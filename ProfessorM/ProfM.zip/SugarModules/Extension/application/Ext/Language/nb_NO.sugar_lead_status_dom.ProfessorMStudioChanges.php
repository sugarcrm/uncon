<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Ny',
  'Assigned' => 'Tildelt',
  'In Process' => 'I kø?',
  'Converted' => 'Konvertert',
  'Recycled' => 'Gjenvunnet',
  'Dead' => 'Inaktiviv',
);