<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Neighborhood',
  'Banking' => 'Small City',
  'Biotechnology' => 'Large City',
  'Chemicals' => 'Metropolis',
  'Communications' => 'Small Country',
  'Construction' => 'Large Country',
  'Consulting' => 'Continent',
  'Education' => 'Planet',
  'Electronics' => 'Solar System',
  'Energy' => 'Galaxy',
  'Engineering' => 'Universe',
  'Entertainment' => 'Multiverse',
  'Other' => 'Other',
);