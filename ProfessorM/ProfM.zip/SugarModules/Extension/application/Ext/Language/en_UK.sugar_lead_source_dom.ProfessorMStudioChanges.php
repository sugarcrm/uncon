<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Cold Call',
  'Existing Customer' => 'Existing Customer',
  'Self Generated' => 'Self Generated',
  'Employee' => 'Employee',
  'Partner' => 'Partner',
  'Public Relations' => 'Public Relations',
  'Direct Mail' => 'Direct Mail',
  'Web Site' => 'Web Site',
  'Word of mouth' => 'Word of mouth',
  'Campaign' => 'Campaign',
  'Other' => 'Other',
);