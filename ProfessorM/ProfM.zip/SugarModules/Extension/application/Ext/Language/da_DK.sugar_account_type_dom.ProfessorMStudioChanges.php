<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analytiker',
  'Competitor' => 'Konkurrent',
  'Customer' => 'Kunde',
  'Integrator' => 'Integrator',
  'Other' => 'Andet',
);