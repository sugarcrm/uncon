<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Odjeća',
  'Banking' => 'Bankarstvo',
  'Biotechnology' => 'Biotehnologija',
  'Chemicals' => 'Kemikalije',
  'Communications' => 'Komunikacije',
  'Construction' => 'Građevinarstvo',
  'Consulting' => 'Savjetovanje',
  'Education' => 'Obrazovanje',
  'Electronics' => 'Elektronika',
  'Energy' => 'Energija',
  'Engineering' => 'Inženjerstvo',
  'Entertainment' => 'Zabava',
  'Other' => 'Ostalo',
);