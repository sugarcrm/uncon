<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'אנליסט',
  'Competitor' => 'מתחרה',
  'Customer' => 'לקוח',
  'Integrator' => 'אינטגרטור',
  'Other' => 'אחר',
);