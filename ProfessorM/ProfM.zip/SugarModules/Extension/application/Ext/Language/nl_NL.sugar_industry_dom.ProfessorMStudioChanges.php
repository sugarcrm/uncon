<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Kleding',
  'Banking' => 'Banken',
  'Biotechnology' => 'Biotechnologie',
  'Chemicals' => 'Chemisch',
  'Communications' => 'Communicatie',
  'Construction' => 'Bouw',
  'Consulting' => 'Advies',
  'Education' => 'Onderwijs',
  'Electronics' => 'Electronica',
  'Energy' => 'Energie',
  'Engineering' => 'Techniek',
  'Entertainment' => 'Amusement',
  'Other' => 'Anders',
);