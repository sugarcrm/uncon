<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Uopfordret opkald',
  'Existing Customer' => 'Eksisterende kunde',
  'Self Generated' => 'Selvgenereret',
  'Employee' => 'Medarbejder',
  'Partner' => 'Partner',
  'Public Relations' => 'PR',
  'Direct Mail' => 'Direct mail',
  'Web Site' => 'Websted',
  'Word of mouth' => 'Mund-til-mund',
  'Campaign' => 'Kampagne',
  'Other' => 'Andet',
);