<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Soitto',
  'Existing Customer' => 'Olemassa oleva asiakas',
  'Self Generated' => 'Itse luotu',
  'Employee' => 'Työntekijä',
  'Partner' => 'Kumppani',
  'Public Relations' => 'Suhdetoiminta',
  'Direct Mail' => 'Suoraposti',
  'Web Site' => 'Internet-sivusto',
  'Word of mouth' => 'Kuultu joltakin',
  'Campaign' => 'Kampanja',
  'Other' => 'Muu',
);