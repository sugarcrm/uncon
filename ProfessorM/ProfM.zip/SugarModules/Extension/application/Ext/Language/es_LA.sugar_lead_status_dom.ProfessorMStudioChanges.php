<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Nuevo',
  'Assigned' => 'Asignado',
  'In Process' => 'En Proceso',
  'Converted' => 'Convertido',
  'Recycled' => 'Reciclado',
  'Dead' => 'Muerto',
);