<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Nieuw',
  'Assigned' => 'Toegewezen',
  'In Process' => 'In behandeling',
  'Converted' => 'Geconverteerd',
  'Recycled' => 'Hergebruikt/Opnieuw',
  'Dead' => 'Geen resultaat',
);