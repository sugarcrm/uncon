<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Novo',
  'Assigned' => 'Dodijeljeno',
  'In Process' => 'U tijeku',
  'Converted' => 'Pretvoreno',
  'Recycled' => 'Reciklirano',
  'Dead' => 'Otkazano',
);