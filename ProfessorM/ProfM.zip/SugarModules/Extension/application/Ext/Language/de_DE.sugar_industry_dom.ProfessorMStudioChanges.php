<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Bekleidungsindustrie',
  'Banking' => 'Bankwesen',
  'Biotechnology' => 'Biotechnologie',
  'Chemicals' => 'Chemieindustrie',
  'Communications' => 'Kommunikation',
  'Construction' => 'Baugewerbe',
  'Consulting' => 'Beratung',
  'Education' => 'Bildungwesen',
  'Electronics' => 'Elektronik',
  'Energy' => 'Energiesektor',
  'Engineering' => 'Entwicklung',
  'Entertainment' => 'Unterhaltungsindustrie',
  'Other' => 'Andere',
);