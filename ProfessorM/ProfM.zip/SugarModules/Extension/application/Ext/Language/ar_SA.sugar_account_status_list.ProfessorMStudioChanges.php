<?php 
$app_list_strings['account_status_list'] = array (
  'Active' => 'Active',
  'Defunct' => 'Defunct',
  'Reactivated' => 'Reactivated',
  'Unknown' => 'Unknown',
);