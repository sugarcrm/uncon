<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => '의류 및 패션',
  'Banking' => '은행',
  'Biotechnology' => '생명공학',
  'Chemicals' => '석유화학',
  'Communications' => '정보통신',
  'Construction' => '건설',
  'Consulting' => '컨설팅',
  'Education' => '교육',
  'Electronics' => '전자',
  'Energy' => '자원',
  'Engineering' => '엔지니어링',
  'Entertainment' => '엔터테인먼트',
  'Other' => '기타',
);