<?php 
$app_list_strings['grading_list'] = array (
  'A Plus' => 'A+',
  'A' => 'A',
  'A Minus' => 'A-',
  'B Plus' => 'B+',
  'B' => 'B',
  'B Minus' => 'B-',
  'C Plus' => 'C+',
  'C' => 'C',
  'C Minus' => 'C-',
  'D Plus' => 'D+',
  'D' => 'D',
  'D Minus' => 'D-',
  'F' => 'F',
);