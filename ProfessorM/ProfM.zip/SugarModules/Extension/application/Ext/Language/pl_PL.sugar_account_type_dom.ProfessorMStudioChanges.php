<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'Analityk',
  'Competitor' => 'Konkurencja',
  'Customer' => 'Klient',
  'Integrator' => 'Integrator',
  'Other' => 'Inne',
);