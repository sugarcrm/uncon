<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Naujas',
  'Assigned' => 'Priskirta',
  'In Process' => 'Vykdoma',
  'Converted' => 'Konvertuota',
  'Recycled' => 'Atnaujinta',
  'Dead' => 'Nebegalioja',
);