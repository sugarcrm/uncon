<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Textil',
  'Banking' => 'Banca',
  'Biotechnology' => 'Biotecnología',
  'Chemicals' => 'Química',
  'Communications' => 'Comunicaciones',
  'Construction' => 'Construcción',
  'Consulting' => 'Consultoría',
  'Education' => 'Educación',
  'Electronics' => 'Electrónica',
  'Energy' => 'Energía',
  'Engineering' => 'Ingeniería',
  'Entertainment' => 'Entretenimiento',
  'Other' => 'Otro',
);