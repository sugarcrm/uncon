<?php 
$app_list_strings['industry_dom'] = array (
  '' => '',
  'Apparel' => 'Apģērbi',
  'Banking' => 'Banku pakalpojumi',
  'Biotechnology' => 'Biotehnoloģija',
  'Chemicals' => 'Ķīmiskā rūpniecība',
  'Communications' => 'Komunikācijas',
  'Construction' => 'Celtniecība',
  'Consulting' => 'Konsultācijas',
  'Education' => 'Izglītība',
  'Electronics' => 'Elektronika',
  'Energy' => 'Enerģētika',
  'Engineering' => 'Inženierija',
  'Entertainment' => 'Izklaide',
  'Other' => 'Cits',
);