<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'New',
  'Assigned' => 'Assessing Skills',
  'In Process' => 'Processing Application',
  'Converted' => 'Converted',
  'Recycled' => 'Deferred',
  'Dead' => 'Declined',
);