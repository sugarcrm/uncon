<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Novo',
  'Assigned' => 'Atribuído',
  'In Process' => 'Em processamento',
  'Converted' => 'Convertido',
  'Recycled' => 'Reciclado',
  'Dead' => 'Morto',
);