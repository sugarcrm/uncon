<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Uus',
  'Assigned' => 'Määratud',
  'In Process' => 'Pooleli',
  'Converted' => 'Muudetud',
  'Recycled' => 'Ümbertöödeldud',
  'Dead' => 'Surnud',
);