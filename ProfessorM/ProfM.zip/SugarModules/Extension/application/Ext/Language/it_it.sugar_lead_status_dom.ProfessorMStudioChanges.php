<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'Nuovo',
  'Assigned' => 'Confermato',
  'In Process' => 'In Corso',
  'Converted' => 'Convertito',
  'Recycled' => 'Riciclato',
  'Dead' => 'Perso',
);