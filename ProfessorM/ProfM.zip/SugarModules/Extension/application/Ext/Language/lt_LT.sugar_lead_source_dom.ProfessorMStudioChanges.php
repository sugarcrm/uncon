<?php 
$app_list_strings['lead_source_dom'] = array (
  '' => '',
  'Cold Call' => 'Aktyvus pardavimas',
  'Existing Customer' => 'Esamas klientas',
  'Self Generated' => 'Savarankiškai sukurtas',
  'Employee' => 'Darbuotojas',
  'Partner' => 'Partneris',
  'Public Relations' => 'Viešieji ryšiai',
  'Direct Mail' => 'Tiesioginis paštas',
  'Web Site' => 'Svetainė',
  'Word of mouth' => 'Rekomendacija žodžiu',
  'Campaign' => 'Kampanija',
  'Other' => 'Kita',
);