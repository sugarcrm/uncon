<?php 
$app_list_strings['lead_status_dom'] = array (
  '' => '',
  'New' => 'חדש',
  'Assigned' => 'הוקצו',
  'In Process' => 'בתהליך',
  'Converted' => 'הומר',
  'Recycled' => 'מוחזר',
  'Dead' => 'מת',
);