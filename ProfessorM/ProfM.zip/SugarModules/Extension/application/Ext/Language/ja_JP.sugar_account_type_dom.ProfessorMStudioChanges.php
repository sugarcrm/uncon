<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Analyst' => 'アナリスト',
  'Competitor' => '競合他社',
  'Customer' => '顧客',
  'Integrator' => 'インテグレーター',
  'Other' => 'その他',
);