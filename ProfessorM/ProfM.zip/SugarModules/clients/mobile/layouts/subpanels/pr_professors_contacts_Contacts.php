<?php
// created: 2017-08-08 10:33:48
$viewdefs['Contacts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PR_PROFESSORS_CONTACTS_FROM_PR_PROFESSORS_TITLE',
  'context' => 
  array (
    'link' => 'pr_professors_contacts',
  ),
);

$viewdefs['Contacts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PR_PROFESSORS_CONTACTS_FROM_PR_PROFESSORS_TITLE',
  'context' => 
  array (
    'link' => 'pr_professors_contacts',
  ),
);