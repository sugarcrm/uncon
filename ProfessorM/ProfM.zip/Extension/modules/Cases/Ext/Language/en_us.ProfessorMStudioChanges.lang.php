<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_ACCOUNT_NAME'] = 'Super Group Name:';
$mod_strings['LBL_ACCOUNT_ID'] = 'Super Group ID';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'Students';
$mod_strings['LBL_CONTACT_CASE_TITLE'] = 'Student-Case:';
$mod_strings['LBL_INVITEE'] = 'Students';
$mod_strings['NTC_REMOVE_INVITEE'] = 'Are you sure you want to remove this Student from the Case?';
$mod_strings['LBL_CONTACT_HISTORY_SUBPANEL_TITLE'] = 'Related Students&#039; Emails';
$mod_strings['ERR_DELETE_RECORD'] = 'You must specify a record number to delete the Super Group.';
$mod_strings['LBL_ACCOUNTS_SUBPANEL_TITLE'] = 'Super Groups';
$mod_strings['LBL_MEMBER_OF'] = 'Super Group';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Super Group Name';
$mod_strings['LBL_ACCOUNT_NAME_OWNER'] = 'Super Group Name Owner';
$mod_strings['LBL_ACCOUNT_NAME_MOD'] = 'Super Group Name Mod';
$mod_strings['LBL_PORTAL_TOUR_RECORDS_INTRO'] = 'The Cases module is for managing support issues that affect your Super Group.  Use the arrows below to go through a quick tour.';
$mod_strings['LBL_PORTAL_TOUR_RECORDS_PAGE'] = 'This page shows the list of existing Cases associated with your Super Group.';
