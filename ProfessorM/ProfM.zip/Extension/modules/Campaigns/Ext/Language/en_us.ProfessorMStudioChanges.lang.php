<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_CAMPAIGN_ACCOUNTS_SUBPANEL_TITLE'] = 'Super Groups';
$mod_strings['LBL_CAMPAIGN_LEAD_SUBPANEL_TITLE'] = 'Applicants';
$mod_strings['LBL_OPPORTUNITY_SUBPANEL_TITLE'] = 'Donations';
$mod_strings['LBL_CONTACTS'] = 'Students';
$mod_strings['LBL_LOG_ENTRIES_CONTACT_TITLE'] = 'Students Created';
$mod_strings['LBL_ACCOUNTS'] = 'Super Groups';
$mod_strings['LBL_OPPORTUNITIES'] = 'Donations';
$mod_strings['LBL_LOG_ENTRIES_LEAD_TITLE'] = 'Applicants Created';
