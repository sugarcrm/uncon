<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_ACCOUNT_NAME'] = 'Super Group Name:';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'Students';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Super Group Name';
$mod_strings['LBL_OPPORTUNITY'] = 'Donation';
$mod_strings['LBL_OPPORTUNITY_ID'] = 'Donation ID';
