<?php
 // created: 2017-08-07 20:35:04
$dictionary['Account']['fields']['ratesg_c']['labelValue']='Rating';
$dictionary['Account']['fields']['ratesg_c']['dependency']='';
$dictionary['Account']['fields']['ratesg_c']['visibility_grid']='';

 ?>