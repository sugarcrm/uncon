<?php
$dictionary['Account']['fields']['revenuelineitems']['workflow'] = true;