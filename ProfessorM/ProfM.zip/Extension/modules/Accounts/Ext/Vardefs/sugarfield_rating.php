<?php
 // created: 2017-08-07 20:30:54
$dictionary['Account']['fields']['rating']['len']='100';
$dictionary['Account']['fields']['rating']['audited']=false;
$dictionary['Account']['fields']['rating']['massupdate']=false;
$dictionary['Account']['fields']['rating']['comments']='An arbitrary rating for this company for use in comparisons with others';
$dictionary['Account']['fields']['rating']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['rating']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['rating']['merge_filter']='disabled';
$dictionary['Account']['fields']['rating']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Account']['fields']['rating']['calculated']=false;

 ?>