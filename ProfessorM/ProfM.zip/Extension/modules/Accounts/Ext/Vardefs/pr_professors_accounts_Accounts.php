<?php
// created: 2017-08-08 10:33:48
$dictionary["Account"]["fields"]["pr_professors_accounts"] = array (
  'name' => 'pr_professors_accounts',
  'type' => 'link',
  'relationship' => 'pr_professors_accounts',
  'source' => 'non-db',
  'module' => 'PR_Professors',
  'bean_name' => false,
  'vname' => 'LBL_PR_PROFESSORS_ACCOUNTS_FROM_PR_PROFESSORS_TITLE',
  'id_name' => 'pr_professors_accountspr_professors_ida',
);
