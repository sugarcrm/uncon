<?php
 // created: 2017-08-07 20:21:33
$dictionary['Account']['fields']['status_c']['labelValue']='Status';
$dictionary['Account']['fields']['status_c']['dependency']='';
$dictionary['Account']['fields']['status_c']['visibility_grid']='';

 ?>