<?php
 // created: 2017-08-07 20:12:20
$dictionary['Account']['fields']['shipping_address_country']['audited']=false;
$dictionary['Account']['fields']['shipping_address_country']['massupdate']=false;
$dictionary['Account']['fields']['shipping_address_country']['comments']='The country used for the shipping address';
$dictionary['Account']['fields']['shipping_address_country']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['shipping_address_country']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['shipping_address_country']['merge_filter']='disabled';
$dictionary['Account']['fields']['shipping_address_country']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Account']['fields']['shipping_address_country']['calculated']=false;

 ?>