<?php
$dictionary['Task']['fields']['revenuelineitems']['workflow'] = true;