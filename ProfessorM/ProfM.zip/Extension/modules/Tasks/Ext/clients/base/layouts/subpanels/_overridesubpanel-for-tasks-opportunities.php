<?php
//auto-generated file DO NOT EDIT
$viewdefs['Tasks']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'opportunities',
  'view' => 'subpanel-for-tasks-opportunities',
);
