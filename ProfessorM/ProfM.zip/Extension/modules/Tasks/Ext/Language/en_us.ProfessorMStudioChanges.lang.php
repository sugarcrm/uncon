<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_CONTACT_NAME'] = 'Student Name ';
$mod_strings['LBL_LIST_CONTACT'] = 'Student';
$mod_strings['LBL_CONTACT'] = 'Student:';
$mod_strings['ERR_DELETE_RECORD'] = 'You must specify a record number to delete the Student.';
$mod_strings['LBL_CONTACT_FIRST_NAME'] = 'Student First Name';
$mod_strings['LBL_CONTACT_LAST_NAME'] = 'Student Last Name';
$mod_strings['LBL_CONTACT_ID'] = 'Student ID:';
$mod_strings['LBL_CONTACT_PHONE'] = 'Student Phone:';
