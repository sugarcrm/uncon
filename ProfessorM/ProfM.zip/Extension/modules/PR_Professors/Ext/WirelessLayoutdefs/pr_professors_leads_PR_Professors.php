<?php
 // created: 2017-08-08 10:33:48
$layout_defs["PR_Professors"]["subpanel_setup"]['pr_professors_leads'] = array (
  'order' => 100,
  'module' => 'Leads',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_PR_PROFESSORS_LEADS_FROM_LEADS_TITLE',
  'get_subpanel_data' => 'pr_professors_leads',
);
