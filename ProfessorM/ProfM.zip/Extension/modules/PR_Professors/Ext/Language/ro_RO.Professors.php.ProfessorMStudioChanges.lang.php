<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/PR_Professors/Ext/Language/ro_RO.Professors.php

// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/PR_Professors/Ext/Language/ro_RO.Professors.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_PR_PROFESSORS_ACCOUNTS_FROM_ACCOUNTS_TITLE'] = 'Super Groups';
$mod_strings['LBL_PR_PROFESSORS_ACCOUNTS_FROM_PR_PROFESSORS_TITLE'] = 'Super Groups';
$mod_strings['LBL_PR_PROFESSORS_LEADS_FROM_LEADS_TITLE'] = 'Applicants';
$mod_strings['LBL_PR_PROFESSORS_LEADS_FROM_PR_PROFESSORS_TITLE'] = 'Applicants';
$mod_strings['LBL_PR_PROFESSORS_CONTACTS_FROM_CONTACTS_TITLE'] = 'Students';
$mod_strings['LBL_PR_PROFESSORS_CONTACTS_FROM_PR_PROFESSORS_TITLE'] = 'Students';

?>
<?php
// Merged from custom/Extension/modules/PR_Professors/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_PR_PROFESSORS_ACCOUNTS_FROM_ACCOUNTS_TITLE'] = 'Super Groups';
$mod_strings['LBL_PR_PROFESSORS_ACCOUNTS_FROM_PR_PROFESSORS_TITLE'] = 'Super Groups';
$mod_strings['LBL_PR_PROFESSORS_LEADS_FROM_LEADS_TITLE'] = 'Applicants';
$mod_strings['LBL_PR_PROFESSORS_LEADS_FROM_PR_PROFESSORS_TITLE'] = 'Applicants';
$mod_strings['LBL_PR_PROFESSORS_CONTACTS_FROM_CONTACTS_TITLE'] = 'Students';
$mod_strings['LBL_PR_PROFESSORS_CONTACTS_FROM_PR_PROFESSORS_TITLE'] = 'Students';


?>
<?php
// Merged from custom/Extension/modules/PR_Professors/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_PR_PROFESSORS_ACCOUNTS_FROM_ACCOUNTS_TITLE'] = 'Super Groups';
$mod_strings['LBL_PR_PROFESSORS_ACCOUNTS_FROM_PR_PROFESSORS_TITLE'] = 'Super Groups';
$mod_strings['LBL_PR_PROFESSORS_LEADS_FROM_LEADS_TITLE'] = 'Applicants';
$mod_strings['LBL_PR_PROFESSORS_LEADS_FROM_PR_PROFESSORS_TITLE'] = 'Applicants';
$mod_strings['LBL_PR_PROFESSORS_CONTACTS_FROM_CONTACTS_TITLE'] = 'Students';
$mod_strings['LBL_PR_PROFESSORS_CONTACTS_FROM_PR_PROFESSORS_TITLE'] = 'Students';

?>
