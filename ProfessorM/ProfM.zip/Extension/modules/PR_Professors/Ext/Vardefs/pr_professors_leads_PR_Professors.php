<?php
// created: 2017-08-08 10:33:48
$dictionary["PR_Professors"]["fields"]["pr_professors_leads"] = array (
  'name' => 'pr_professors_leads',
  'type' => 'link',
  'relationship' => 'pr_professors_leads',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_PR_PROFESSORS_LEADS_FROM_PR_PROFESSORS_TITLE',
  'id_name' => 'pr_professors_leadspr_professors_ida',
  'link-type' => 'many',
  'side' => 'left',
);
