<?php
// created: 2017-08-08 10:33:48
$dictionary["PR_Professors"]["fields"]["pr_professors_accounts"] = array (
  'name' => 'pr_professors_accounts',
  'type' => 'link',
  'relationship' => 'pr_professors_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'vname' => 'LBL_PR_PROFESSORS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'pr_professors_accountsaccounts_idb',
);
