<?php
//auto-generated file DO NOT EDIT
$layout_defs['Project']['subpanel_setup']['opportunities']['override_subpanel_name'] = 'Project_subpanel_opportunities';
?>