<?php
 // created: 2017-08-07 15:50:43
$dictionary['Lead']['fields']['alias_c']['labelValue']='Alias';
$dictionary['Lead']['fields']['alias_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Lead']['fields']['alias_c']['enforced']='';
$dictionary['Lead']['fields']['alias_c']['dependency']='';

 ?>