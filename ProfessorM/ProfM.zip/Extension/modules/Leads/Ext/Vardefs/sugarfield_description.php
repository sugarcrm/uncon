<?php
 // created: 2017-08-07 15:52:06
$dictionary['Lead']['fields']['description']['audited']=false;
$dictionary['Lead']['fields']['description']['massupdate']=false;
$dictionary['Lead']['fields']['description']['comments']='Background information';
$dictionary['Lead']['fields']['description']['duplicate_merge']='enabled';
$dictionary['Lead']['fields']['description']['duplicate_merge_dom_value']='1';
$dictionary['Lead']['fields']['description']['merge_filter']='disabled';
$dictionary['Lead']['fields']['description']['full_text_search']=array (
  'enabled' => true,
  'boost' => '0.7',
  'searchable' => true,
);
$dictionary['Lead']['fields']['description']['calculated']=false;
$dictionary['Lead']['fields']['description']['rows']='6';
$dictionary['Lead']['fields']['description']['cols']='80';

 ?>