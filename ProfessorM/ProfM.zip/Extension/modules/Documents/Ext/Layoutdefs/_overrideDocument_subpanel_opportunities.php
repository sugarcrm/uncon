<?php
//auto-generated file DO NOT EDIT
$layout_defs['Documents']['subpanel_setup']['opportunities']['override_subpanel_name'] = 'Document_subpanel_opportunities';
?>