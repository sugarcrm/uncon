<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_ACCOUNTS_SUBPANEL_TITLE'] = 'Super Groups';
$mod_strings['LBL_CONTACTS_SUBPANEL_TITLE'] = 'Students';
$mod_strings['LBL_OPPORTUNITIES_SUBPANEL_TITLE'] = 'Donations';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Funding Line Items';
