<?php
$dictionary['Opportunity']['fields']['revenuelineitems']['workflow'] = true;