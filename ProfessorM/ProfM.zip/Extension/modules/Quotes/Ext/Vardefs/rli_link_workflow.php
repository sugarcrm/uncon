<?php
$dictionary['Quote']['fields']['revenuelineitems']['workflow'] = true;