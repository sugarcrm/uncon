<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_SHIPPING_ACCOUNT_NAME'] = 'Shipping Super Group Name:';
$mod_strings['LBL_SHIPPING_CONTACT_NAME'] = 'Shipping Student Name:';
$mod_strings['LBL_SHIPPING_CONTACT_ID'] = 'Shipping Student Id:';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Super Group Name:';
$mod_strings['LBL_ACCOUNT_ID'] = 'Super Group Id';
$mod_strings['LBL_BILLING_ACCOUNT_NAME'] = 'Billing Super Group Name:';
$mod_strings['LBL_BILLING_CONTACT_NAME'] = 'Billing Student Name:';
$mod_strings['LBL_BILLING_CONTACT_ID'] = 'Billing Student Id:';
$mod_strings['LBL_OPPORTUNITY_NAME'] = 'Donation Name:';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Super Group Name';
$mod_strings['EXCEPTION_QUOTE_ALREADY_CONVERTED'] = 'Quote Already Converted To Donation';
$mod_strings['LBL_REVENUELINEITEMS'] = 'Funding Line Items';
