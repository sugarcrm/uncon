<?php
 // created: 2017-08-07 16:16:51
$dictionary['Contact']['fields']['lead_source']['len']=100;
$dictionary['Contact']['fields']['lead_source']['audited']=false;
$dictionary['Contact']['fields']['lead_source']['massupdate']=true;
$dictionary['Contact']['fields']['lead_source']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['lead_source']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['lead_source']['merge_filter']='disabled';
$dictionary['Contact']['fields']['lead_source']['calculated']=false;
$dictionary['Contact']['fields']['lead_source']['dependency']=false;

 ?>