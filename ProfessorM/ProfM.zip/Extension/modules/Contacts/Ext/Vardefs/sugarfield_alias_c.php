<?php
 // created: 2017-08-07 16:15:53
$dictionary['Contact']['fields']['alias_c']['labelValue']='Alias';
$dictionary['Contact']['fields']['alias_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['alias_c']['enforced']='';
$dictionary['Contact']['fields']['alias_c']['dependency']='';

 ?>