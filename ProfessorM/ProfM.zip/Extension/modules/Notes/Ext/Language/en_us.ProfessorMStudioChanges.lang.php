<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_CONTACT_NAME'] = 'Student:';
$mod_strings['LBL_CONTACT_ID'] = 'Student ID:';
$mod_strings['LBL_LIST_CONTACT_NAME'] = 'Student';
$mod_strings['LBL_LIST_CONTACT'] = 'Student';
$mod_strings['ERR_DELETE_RECORD'] = 'You must specify a record number to delete the Super Group.';
$mod_strings['LBL_ACCOUNT_ID'] = 'Super Group ID:';
$mod_strings['LBL_OPPORTUNITY_ID'] = 'Donation ID:';
$mod_strings['LBL_LEAD_ID'] = 'Applicant ID:';
$mod_strings['LBL_REVENUELINEITEMS'] = 'Funding Line Items';
