<?php
//auto-generated file DO NOT EDIT
$viewdefs['Notes']['base']['layout']['subpanels']['components'][]['override_subpanel_list_view'] = array (
  'link' => 'opportunities',
  'view' => 'subpanel-for-notes-opportunities',
);
