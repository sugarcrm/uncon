<?php
$manifest = array (
  'id' => 'REPLACE_ME',
  'name' => 'SugarCRM ML Package Template',
  'description' => 'SugarCRM ML Package Template',
  'version' => '0.1',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2016-05-26 10:17:14',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.7.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/test.php',
      'to' => 'custom/test.php',
    ),
  ),
);
