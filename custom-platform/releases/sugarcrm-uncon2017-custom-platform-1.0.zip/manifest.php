<?php
$manifest = array (
  'id' => 'uncon2017-custom-platform',
  'name' => 'UnCon 2017 Custom Platform Registration',
  'description' => 'UnCon 2017 Custom Platform Registration',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2017-11-01 20:30:43',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.9.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Platforms/rename-this-file.php',
      'to' => 'custom/Extension/application/Ext/Platforms/rename-this-file.php',
    ),
  ),
);
