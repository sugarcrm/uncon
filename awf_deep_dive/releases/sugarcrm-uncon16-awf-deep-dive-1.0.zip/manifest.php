<?php
$manifest = array (
  'id' => 'uncon16-awf-deep-dive-1.0',
  'name' => 'SugarCRM UnCon 2016 Advanced Workflow Deep Dive',
  'description' => 'SugarCRM UnCon 2016 Advanced Workflow Deep Dive',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2016-06-10 20:55:26',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.7.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/JSGroupings/pmsegrouping.php',
      'to' => 'custom/Extension/application/Ext/JSGroupings/pmsegrouping.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/include/javascript/pmse/activity.js',
      'to' => 'custom/include/javascript/pmse/activity.js',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/engine/PMSEElements/PMSECapitalizeName.php',
      'to' => 'custom/modules/pmse_Inbox/engine/PMSEElements/PMSECapitalizeName.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/modules/pmse_Project/css/jcore.adam.css',
      'to' => 'modules/pmse_Project/css/jcore.adam.css',
    ),
    4 => 
    array (
      'from' => '<basepath>/src/modules/pmse_Project/img/purple-cross.png',
      'to' => 'modules/pmse_Project/img/purple-cross.png',
    ),
  ),
);
