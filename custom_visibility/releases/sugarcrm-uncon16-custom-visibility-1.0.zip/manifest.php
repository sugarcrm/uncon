<?php
$manifest = array (
  'id' => 'uncon16-custom-visibility-1.0',
  'name' => 'SugarCRM UnCon 2016 Custom Visibility Demo',
  'description' => 'SugarCRM UnCon 2016 Custom Visibility Demo',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2016-05-26 03:00:58',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.7.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Opportunities/Ext/Vardefs/opp_visibility.php',
      'to' => 'custom/Extension/modules/Opportunities/Ext/Vardefs/opp_visibility.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/src/Elasticsearch/Provider/Visibility/Filter/OpportunitySalesStagesFilter.php',
      'to' => 'custom/src/Elasticsearch/Provider/Visibility/Filter/OpportunitySalesStagesFilter.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/data/visibility/FilterOpportunities.php',
      'to' => 'custom/data/visibility/FilterOpportunities.php',
    ),
  ),
);
