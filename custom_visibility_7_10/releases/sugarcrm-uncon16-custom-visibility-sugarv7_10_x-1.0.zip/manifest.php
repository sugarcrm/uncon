<?php
$manifest = array (
  'id' => 'uncon16-custom-visibility-sugarv7_10_x-1.0',
  'name' => 'SugarCRM UnCon 2016 Custom Visibility Demo for Sugar 7.10.x',
  'description' => 'SugarCRM UnCon 2016 Custom Visibility Demo for Sugar 7.10.x',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2017-12-06 19:00:06',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.1[0-9].[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Opportunities/Ext/Vardefs/opp_visibility.php',
      'to' => 'custom/Extension/modules/Opportunities/Ext/Vardefs/opp_visibility.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/data/visibility/FilterOpportunities.php',
      'to' => 'custom/data/visibility/FilterOpportunities.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/src/Elasticsearch/Provider/Visibility/Filter/OpportunitySalesStagesFilter.php',
      'to' => 'custom/src/Elasticsearch/Provider/Visibility/Filter/OpportunitySalesStagesFilter.php',
    ),
  ),
);
