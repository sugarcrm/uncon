<?php
$mod_strings['LBL_PREFERRED_LANGUAGE'] = 'Preferred Language';
