<?php
$module = 'Leads';
$viewdefs[$module]['base']['view']['record']['panels'][1]['fields'][] = 'preferred_language';
