<?php
$manifest = array (
  'id' => 'uncon217-customizing-awf',
  'name' => 'UnCon 2017 Customizing Advanced Workflow',
  'description' => 'UnCon 2017 Customizing Advanced Workflow',
  'version' => '0.1b',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2017-09-18 15:37:28',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.9.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/JSGroupings/pmsegroupings.php',
      'to' => 'custom/Extension/application/Ext/JSGroupings/pmsegroupings.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Language/en_us.preferred_lang_list.php',
      'to' => 'custom/Extension/application/Ext/Language/en_us.preferred_lang_list.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/clients/base/views/record/addPreferredLanguage.php',
      'to' => 'custom/Extension/modules/Leads/Ext/clients/base/views/record/addPreferredLanguage.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/Language/en_us.pref_language.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.pref_language.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/Vardefs/leads_pref_lang.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/leads_pref_lang.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/src/custom/include/javascript/pmse/activity.js',
      'to' => 'custom/include/javascript/pmse/activity.js',
    ),
    6 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/.DS_Store',
      'to' => 'custom/modules/pmse_Inbox/.DS_Store',
    ),
    7 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Inbox/engine/PMSEElements/PMSETranslateWelcome.php',
      'to' => 'custom/modules/pmse_Inbox/engine/PMSEElements/PMSETranslateWelcome.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Project/img/translate-email-001.png',
      'to' => 'custom/modules/pmse_Project/img/translate-email-001.png',
    ),
    9 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Project/img/translate-email-001.svg',
      'to' => 'custom/modules/pmse_Project/img/translate-email-001.svg',
    ),
    10 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Project/img/translate-email-002.png',
      'to' => 'custom/modules/pmse_Project/img/translate-email-002.png',
    ),
    11 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Project/img/translate-email-002.svg',
      'to' => 'custom/modules/pmse_Project/img/translate-email-002.svg',
    ),
    12 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Project/img/translate-icon-005.png',
      'to' => 'custom/modules/pmse_Project/img/translate-icon-005.png',
    ),
    13 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Project/img/translate-icon-006.png',
      'to' => 'custom/modules/pmse_Project/img/translate-icon-006.png',
    ),
    14 => 
    array (
      'from' => '<basepath>/src/custom/modules/pmse_Project/img/translate-icon-007.png',
      'to' => 'custom/modules/pmse_Project/img/translate-icon-007.png',
    ),
    15 => 
    array (
      'from' => '<basepath>/src/custom/themes/custom.less',
      'to' => 'custom/themes/custom.less',
    ),
  ),
);
