<?php
$manifest = array (
  'id' => 'uncon16-phpunit-tests-1.0',
  'name' => 'SugarCRM UnCon 2016 PHPUnit Test Demo',
  'description' => 'SugarCRM UnCon 2016 PHPUnit Test Demo',
  'version' => '1.0',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2016-06-09 13:49:47',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '^7.7.[\\d]+.[\\d]+$',
    ),
  ),
);
$installdefs = array (
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/include/Commissioner.php',
      'to' => 'include/Commissioner.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/tests/include/CommissionerBetterTest.php',
      'to' => 'tests/include/CommissionerBetterTest.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/tests/include/CommissionerSimpleTest.php',
      'to' => 'tests/include/CommissionerSimpleTest.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/tests/include/CommissionerTest.php',
      'to' => 'tests/include/CommissionerTest.php',
    ),
  ),
);
